﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;

namespace UnitTest
{
    [TestClass]
    public class RegistrarInstitucionDAOTest
    {
        [TestMethod]
        public void PruebaRegistrarInstitucionValida()
        {
            Institucion institucion = new Institucion();
            InstitucionDAO institucionDAO = new InstitucionDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            institucion.nombreInstitucion = "Facultad de Economia";
            institucion.direccion = "Avenida Xalapa esquina Avila Camacho";
            institucion.telefonoInstitucion = "2288189870";
            institucion.tipoInstitucion = "Universidad";

            resultadoObtenido = institucionDAO.RegistrarInstitucion(institucion);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar institución válida");
        }

        [TestMethod]
        public void PruebaRegistrarInstitucionCamposVacios ()
        {
            Institucion institucion = new Institucion();
            InstitucionDAO institucionDAO = new InstitucionDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            institucion.nombreInstitucion = null;
            institucion.direccion = null;
            institucion.telefonoInstitucion = null;
            institucion.tipoInstitucion = null;

            resultadoObtenido = institucionDAO.RegistrarInstitucion(institucion);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar institución con campos vacíos");
        }

        [TestMethod]
        public void PruebaRegistrarInstitucionRepetida()
        {
            Institucion institucion = new Institucion();
            InstitucionDAO institucionDAO = new InstitucionDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            institucion.nombreInstitucion = "FEI";
            institucion.direccion = "Avenida Xalapa esquina Avila Camacho";
            institucion.telefonoInstitucion = "2288189870";
            institucion.tipoInstitucion = "Universidad";

            resultadoObtenido = institucionDAO.RegistrarInstitucion(institucion);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar institución repetida");
        }


    }
}
