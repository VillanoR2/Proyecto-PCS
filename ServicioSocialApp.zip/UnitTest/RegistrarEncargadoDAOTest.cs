﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;

namespace UnitTest
{
    [TestClass]
    public class RegistrarEncargadoDAOTest
    {
        [TestMethod]
        public void RegistrarEncargadoValido()
        {
            Encargado encargado = new Encargado();
            EncargadoDAO encargadoDAO = new EncargadoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            encargado.nombre = "Juan Carlos";
            encargado.apellidos = "Perez Arriaga";
            encargado.idEncargado = "E000000003";
            encargado.correoElectronico = "elrevo@gmail.com";
            encargado.perteneceA = "FEI";

            resultadoObtenido = encargadoDAO.RegistrarEncargado(encargado);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar encargado válido");
        }

        [TestMethod]
        public void RegistrarEncargadoRepetido()
        {
            Encargado encargado = new Encargado();
            EncargadoDAO encargadoDAO = new EncargadoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            encargado.nombre = "Xavier";
            encargado.apellidos = "Limón";
            encargado.idEncargado = "E00000000";
            encargado.correoElectronico = "xavier@gmail.com";
            encargado.perteneceA = "Facultad de estadistica e informatica";

            resultadoObtenido = encargadoDAO.RegistrarEncargado(encargado);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar encargado repetido");
        }

        [TestMethod]
        public void RegistrarEncargadoValoresLargos()
        {
            Encargado encargado = new Encargado();
            EncargadoDAO encargadoDAO = new EncargadoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            encargado.nombre = "Xavier";
            encargado.apellidos = "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL";
            encargado.idEncargado = "E00000000";
            encargado.correoElectronico = "xavier@gmail.com";
            encargado.perteneceA = "Facultad de estadistica e informatica";

            resultadoObtenido = encargadoDAO.RegistrarEncargado(encargado);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar encargado EXCEDE VALORES");
        }

        [TestMethod]
        public void RegistrarEncargadoCamposVacios()
        {
            Encargado encargado = new Encargado();
            EncargadoDAO encargadoDAO = new EncargadoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            encargado.nombre = null;
            encargado.apellidos = null;
            encargado.idEncargado = null;
            encargado.correoElectronico = null;
            encargado.perteneceA = null;

            resultadoObtenido = encargadoDAO.RegistrarEncargado(encargado);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar encargado no válido");
        }
    }
}
