﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicaDeNegocio.Modelo.Emun;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;


namespace UnitTest
{
    [TestClass]
    public class RegistrarCoordinadorDAOTest
    {

        [TestMethod]
        public void PruebaRegistrarCoordinadorValido()
        {
            Coordinador coordinador = new Coordinador();
            CoordinadorDAO metodo = new CoordinadorDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            coordinador.numPersonalCoordinador = "C19060910";
            coordinador.nombre = "Alfredo";
            coordinador.apellidos = "Hernandez Martinez";
            coordinador.correoElectronico = "alfehdz@uv.mx";
            coordinador.carreraCoordinar = Carrera.TecnologiasComputacionales;
            coordinador.contraseñaCoordinador = "alfedo12";

            resultadoObtenido = metodo.RegistrarCoordinador(coordinador);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar coordinador válido");

        }

        [TestMethod]
        public void PruebaRegistrarCoordinadorMatriculaErronea()
        {
            Coordinador coordinador = new Coordinador();
            CoordinadorDAO metodo = new CoordinadorDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            coordinador.numPersonalCoordinador = "C1906091245678987654";
            coordinador.nombre = "Alfredp";
            coordinador.apellidos = "Hernandez Martinez";
            coordinador.correoElectronico = "alfehdz@uv.mx";
            coordinador.carreraCoordinar = Carrera.TecnologiasComputacionales;
            coordinador.contraseñaCoordinador = "alfedo12";

            resultadoObtenido = metodo.RegistrarCoordinador(coordinador);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar coordinador válido");

        }

        [TestMethod]
        public void PruebaRegistrarCoordinadorMatriculaRepetida()
        {
            Coordinador coordinador = new Coordinador();
            CoordinadorDAO metodo = new CoordinadorDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            coordinador.numPersonalCoordinador = "C19060912";
            coordinador.nombre = "Alfredo";
            coordinador.apellidos = "Hernandez Martinez";
            coordinador.correoElectronico = "alfehdz@uv.mx";
            coordinador.carreraCoordinar = Carrera.TecnologiasComputacionales;
            coordinador.contraseñaCoordinador = "alfedo12";

            resultadoObtenido = metodo.RegistrarCoordinador(coordinador);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar coordinador NO válido");

        }
        [TestMethod]
        public void PruebaRegistrarCoordinadorDatosInvalidos()
        {
            Coordinador coordinador = new Coordinador();
            CoordinadorDAO metodo = new CoordinadorDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            coordinador.numPersonalCoordinador = "C19060955555555555555555555512";
            coordinador.nombre = "aaaaaaaaaaaaaaaaaaaaaa";
            coordinador.apellidos = "Hernandez Martinez";
            coordinador.correoElectronico = "alfehdz@uv.mx";
            coordinador.carreraCoordinar = Carrera.TecnologiasComputacionales;
            coordinador.contraseñaCoordinador = "estesunejeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemplodecontraseñaqueexcedelosvalorespermitidosporlabasededatosestablecidap   revisamente";

            resultadoObtenido = metodo.RegistrarCoordinador(coordinador);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar coordinador válido");

        }

        [TestMethod]
        public void PruebaRegistrarCoordinadorVacio()
        {
            Coordinador coordinador = new Coordinador();
            CoordinadorDAO metodo = new CoordinadorDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            coordinador.numPersonalCoordinador = null;
            coordinador.nombre = null;
            coordinador.apellidos = null;
            coordinador.correoElectronico = null;
            coordinador.carreraCoordinar = Carrera.TecnologiasComputacionales;
            coordinador.contraseñaCoordinador = null;

            resultadoObtenido = metodo.RegistrarCoordinador(coordinador);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar coordinador campos vacíos");

        }

    }
}
