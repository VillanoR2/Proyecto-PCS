﻿using System;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class PruebaRegistrarInformacion

    {
        [TestMethod]
        public void PruebaRegistrarAlumnoValido()
        {
            Alumno alumno = new Alumno(); 
            AlumnoDAO metodo = new AlumnoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            alumno.matricula = "S17012942";
            alumno.nombre = "Franco";
            alumno.apellidos = "Hernandez Martinez";
            alumno.correoElectronico = "zs170129@estudiantes.uv.mx";
            alumno.carreraAlumno = Carrera.IngenieriaDeSoftware;
            alumno.contraseñaAlumno = "Trigov2";
            
            resultadoObtenido=metodo.RegistrarAlumno(alumno);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba agregar estudiante válido");

        }


        [TestMethod]
        public void PruebaRegistrarAlumnoValido2()
        {
            Alumno alumno = new Alumno();
            AlumnoDAO metodo = new AlumnoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            alumno.matricula = "S17012941";
            alumno.nombre = "Arturo";
            alumno.apellidos = "Villa Hernández";
            alumno.correoElectronico = "zs17012946@estudiantes.uv.mx";
            alumno.carreraAlumno = Carrera.IngenieriaDeSoftware;
            alumno.contraseñaAlumno = "Trigoverde1";

            resultadoObtenido = metodo.RegistrarAlumno(alumno);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba agregar estudiante válido");

        }

        [TestMethod]
        public void PruebaRegistrarAlumnoNoValido()
        {
            Alumno alumno = new Alumno();
            AlumnoDAO metodo = new AlumnoDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido = true;

            alumno.matricula = "S17012900000";
            alumno.nombre = "Regina";
            alumno.apellidos = "Saavedra";
            alumno.correoElectronico = "zs17012923@estudiantes.uv.mx";
            alumno.carreraAlumno = Carrera.IngenieriaDeSoftware;
            alumno.contraseñaAlumno = "calitom";


            resultadoObtenido = metodo.RegistrarAlumno(alumno);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Matricula excede los valores permitidos");

        }

        [TestMethod]
        public void PruebaRegistrarAlumnoLlavePrimaria()
        {
            Alumno alumno = new Alumno();
            AlumnoDAO metodo = new AlumnoDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            alumno.matricula = "S17012946";
            alumno.nombre = "Juan";
            alumno.apellidos = "Hernandez";
            alumno.correoElectronico = "zs17012943@estudiantes.uv.mx";
            alumno.carreraAlumno = Carrera.IngenieriaDeSoftware;
            alumno.contraseñaAlumno = "juan123";

            resultadoObtenido = metodo.RegistrarAlumno(alumno);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Llave primaria repetida");

        }

        [TestMethod]
        public void PruebaRegistrarAlumnoLlavePrimariaVacia()
        {
            Alumno alumno = new Alumno();
            AlumnoDAO metodo = new AlumnoDAO();
            bool resultadoEsperado = false;
            bool resultadoObtenido;

            alumno.matricula = null;
            alumno.nombre = "Ana";
            alumno.apellidos = "Hernandez";
            alumno.correoElectronico = "zs17012930@estudiantes.uv.mx";
            alumno.carreraAlumno = Carrera.IngenieriaDeSoftware;
            alumno.contraseñaAlumno = "ana123";

            resultadoObtenido = metodo.RegistrarAlumno(alumno);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Llave primaria vacía");

        }


    }
}
