﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicaDeNegocio;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;
namespace UnitTest
{
    [TestClass]
    public class RegistrarTecnicoDAOTest
    {
        [TestMethod]
        public void PruebaRegistrarTecnicoValido()
        {
            TecnicoAcademico tecnicoAcademico = new TecnicoAcademico();
            TecnicoDAO metodo = new TecnicoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            tecnicoAcademico.numPersonalTecnico = "T12345678";
            tecnicoAcademico.nombre = "Martha";
            tecnicoAcademico.apellidos = "Cuevas";
            tecnicoAcademico.contraseñaTecnico = "Martha123";
            tecnicoAcademico.correoElectronico = "martha@gmail.com";
            tecnicoAcademico.auxuliaA = "C00000001";

            resultadoObtenido = metodo.RegistrarTecnico(tecnicoAcademico);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar técnico válido");

        }

        [TestMethod]
        public void PruebaRegistrarTecnicoNoValido()
        {
            TecnicoAcademico tecnicoAcademico = new TecnicoAcademico();
            TecnicoDAO metodo = new TecnicoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            tecnicoAcademico.numPersonalTecnico = "";
            tecnicoAcademico.nombre = "";
            tecnicoAcademico.apellidos = "";
            tecnicoAcademico.contraseñaTecnico = "";
            tecnicoAcademico.correoElectronico = "";
            tecnicoAcademico.auxuliaA = "";

            resultadoObtenido = metodo.RegistrarTecnico(tecnicoAcademico);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar técnico con campos vacíos");

        }

        [TestMethod]
        public void PruebaRegistrarTecnicoLlaveRepetida()
        {
            TecnicoAcademico tecnicoAcademico = new TecnicoAcademico();
            TecnicoDAO metodo = new TecnicoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            tecnicoAcademico.numPersonalTecnico = "T00000001";
            tecnicoAcademico.nombre = "Ana";
            tecnicoAcademico.apellidos = "Perez";
            tecnicoAcademico.contraseñaTecnico = "anaPR2";
            tecnicoAcademico.correoElectronico = "ana@uv.mx";
            tecnicoAcademico.auxuliaA = "C13144";

            resultadoObtenido = metodo.RegistrarTecnico(tecnicoAcademico);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar técnico con llave repetida");

        }

        [TestMethod]
        public void PruebaRegistrarTecnicoCoordinadorNoExiste()
        {
            TecnicoAcademico tecnicoAcademico = new TecnicoAcademico();
            TecnicoDAO metodo = new TecnicoDAO();
            bool resultadoEsperado = true;
            bool resultadoObtenido;

            tecnicoAcademico.numPersonalTecnico = "T123455";
            tecnicoAcademico.nombre = "Ana";
            tecnicoAcademico.apellidos = "Perez";
            tecnicoAcademico.contraseñaTecnico = "anaPR2";
            tecnicoAcademico.correoElectronico = "ana@uv.mx";
            tecnicoAcademico.auxuliaA = "C010000";

            resultadoObtenido = metodo.RegistrarTecnico(tecnicoAcademico);

            Assert.AreEqual(resultadoEsperado, resultadoObtenido, "Prueba registrar técnico con matricula de coordinador incorrecta");

        }
    }
}
