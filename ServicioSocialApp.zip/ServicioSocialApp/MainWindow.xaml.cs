﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;
using LogicaDeNegocio.Util;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo.Emun;

namespace ServicioSocialApp
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            InitializeComponent();
            
        }

        private void Iniciar_Boton_Click(object sender, RoutedEventArgs e)
        {
            String Usuario = txtUsuario.Text;
            String Contraseña = txtContraseña.Password.ToString();

            if (!String.IsNullOrEmpty(Usuario) && !String.IsNullOrEmpty(Contraseña))
            {

                AutenticarUsuario autenticarUsuario = new AutenticarUsuario();

                ResultadoAutenticacion TipoUsuario = autenticarUsuario.resultadoAutenticacion(Usuario, Contraseña);

                if (TipoUsuario == ResultadoAutenticacion.Director)
                {
                    DirectorPrincipal director = new DirectorPrincipal();
                    this.Hide();
                    director.Show();
                }
                else if (TipoUsuario == ResultadoAutenticacion.Alumno)
                {
                    SolicitudDAO solicitudDAO = new SolicitudDAO();
                    AsignacionDAO asignacionDAO = new AsignacionDAO();
                    
                    if(solicitudDAO.ObtenerEstado(txtUsuario.Text) == EstadoSolicitud.EnEspera)
                       {
                        AlumnoEspera alumno = new AlumnoEspera();
                        this.Hide();
                        alumno.Show();
                       }
                    else if (asignacionDAO.ObtenerEstado(txtUsuario.Text) == EstadoServicio.Aceptado)
                    {
                        AlumnoPrincipal1 alumnoPrincipal1 = new AlumnoPrincipal1();
                        this.Hide();
                        alumnoPrincipal1.Show();
                    }
                    else if (solicitudDAO.ObtenerEstado(txtUsuario.Text) == EstadoSolicitud.Aceptada)
                    {
                        AlumnoPrincipal2 alumnoPrincipal2 = new AlumnoPrincipal2();
                        this.Hide();
                        alumnoPrincipal2.Show();
                    }
                    else
                    {
                        MessageBox.Show("Aceso Denegao, usted fue dado de baja.");
                    }
                }

                else if (TipoUsuario == ResultadoAutenticacion.Coordinador)
                {
 
                    SolicitudDAO solicitudDAO = new SolicitudDAO();
                    if((solicitudDAO.ObtenerEstadoEspera() == EstadoSolicitud.EnEspera) || (solicitudDAO.ObtenerEstadoEspera() == EstadoSolicitud.Aceptada))
                    {
                        CoordinadorPrincipal1 coordinador = new CoordinadorPrincipal1();
                        this.Hide();
                        coordinador.Show();
                    }
                    else 
                    {
                        CoordinadorPrincipal2 coordinador2 = new CoordinadorPrincipal2();
                        this.Hide();
                        coordinador2.Show();
                    }
                }

                else if (TipoUsuario == ResultadoAutenticacion.Tecnico)
                {
                    TecnicoPrincipal tecnico = new TecnicoPrincipal();
                    this.Hide();
                    tecnico.Show();
                }
                else
                {
                    MessageBox.Show("Usuario no Valido");
                }
            }
            else
            {
                MessageBox.Show("Datos Incompletos");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
            {
                AlumnoRegistrar alumnoRegistrar = new AlumnoRegistrar();
                this.Hide();
                alumnoRegistrar.Show();
            }
        
    }
}
