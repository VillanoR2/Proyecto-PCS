﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorTecnico.xaml
    /// </summary>
    public partial class CoordinadorTecnico : Window
    {
        public CoordinadorTecnico()
        {
            InitializeComponent();
        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorPrincipal1 coordinadorPrincipal1 = new CoordinadorPrincipal1();
            this.Hide();
            coordinadorPrincipal1.Show();
        }
    }
}
