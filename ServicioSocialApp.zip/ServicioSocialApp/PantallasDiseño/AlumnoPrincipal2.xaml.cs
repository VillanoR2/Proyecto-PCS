﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoPrincipal2.xaml
    /// </summary>
    public partial class AlumnoPrincipal2 : Window
    {
        public AlumnoPrincipal2()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AlumnoEditar alumnoEditar = new AlumnoEditar();
            this.Hide();
            alumnoEditar.Show();
        }
    }
}
