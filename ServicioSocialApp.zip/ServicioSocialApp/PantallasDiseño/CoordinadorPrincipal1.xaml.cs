﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorPrincipal1.xaml
    /// </summary>
    public partial class CoordinadorPrincipal1 : Window
    {
        public CoordinadorPrincipal1()
        {
            InitializeComponent();
        }

        private void BtnProyecto_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorProyecto coordinadorProyecto = new CoordinadorProyecto();

            this.Hide();
            coordinadorProyecto.Show();

        }

        private void BtnCalendario_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            CoordinadorCalendario coordinadorCalendario = new CoordinadorCalendario();
            coordinadorCalendario.Show();
        }

        private void BtnInstitucion_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            CoordinadorInstitucion institucion = new CoordinadorInstitucion();
            institucion.Show();
        }

        private void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorActualizar actualizar = new CoordinadorActualizar();
            this.Hide();
            actualizar.Show();
        }
    }
}
