﻿using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo.Emun;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para TecnicoPrincipal.xaml
    /// </summary>
    public partial class TecnicoPrincipal : Window
    {
        public TecnicoPrincipal()
        {
            InitializeComponent();
           
            llenarGridAlumnosValidar();
        }

        public void llenarGridAlumnosValidar()
        {
         
            AlumnoDAO alumnodao = new AlumnoDAO();

            if (alumnodao.ObtenerCarrera(Carrera.IngenieriaDeSoftware) == Carrera.IngenieriaDeSoftware)
            {
               
                dataAlumnos.ItemsSource = alumnodao.MostrarAlumnosAvance(Carrera.IngenieriaDeSoftware);
               
            }
            else
            {
                MessageBox.Show("No existen alumnos registrados aun.");
                
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

       
    }
}
