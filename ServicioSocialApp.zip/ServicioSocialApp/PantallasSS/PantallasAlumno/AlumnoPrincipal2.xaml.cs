﻿using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;
using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Excepciones;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoPrincipal2.xaml
    /// </summary>
    public partial class AlumnoPrincipal2 : Window
    {
        public AlumnoPrincipal2()
        {
            InitializeComponent();
            LlenarGrid();
            btnGuardar.IsEnabled = false;
            btnEliminarOpcion.IsEnabled = false;
           
        }

        int c = 0;
        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                return validar;
            }

            return validar = true;

        }

        public void LlenarGrid()
        {
            List<Proyecto> proyectos = new List<Proyecto>();

            ProyectoDAO proyecto = new ProyectoDAO();

            if (proyectos.Any())
            {
                MessageBox.Show("No existen Solicitudes de alumnos registrados aun.");
            }
            else
            {
                dataproyectos.ItemsSource = proyecto.MostrarProyectos();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AlumnoEditar alumnoEditar = new AlumnoEditar();
            this.Hide();
            alumnoEditar.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ProyectoDAO proyectoDAO = new ProyectoDAO();

           

            if (ValidarCampo(txtIdProyecto) == false)
            {
                MessageBox.Show("El campo ID Proyecto no tiene ningun dato. Favor de llenar el campo");
            }
            else
            {
                if (proyectoDAO.GetIdProyecto(txtIdProyecto.Text) == true)
                {

                    if (c < 3)
                    {
                        listProyectos.Items.Insert(0, txtIdProyecto.Text);
                        c++;
                        btnEliminarOpcion.IsEnabled = true;
                        txtIdProyecto.Clear();
                        if (c == 2)
                        {
                            btnGuardar.IsEnabled = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Solo se permite seleccionar tres opciones de proyecto.");
                        btnAdd.IsEnabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("El ID Proyecto no valido.");
                }
            }
                
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            SolicitudDAO solicitud = new SolicitudDAO();

            String proyecto1 = listProyectos.Items.GetItemAt(0).ToString();

            String proyecto2 = listProyectos.Items.GetItemAt(1).ToString();

            String proyecto3 = listProyectos.Items.GetItemAt(2).ToString();

            if(ValidarCampo(txtMatriculaAlumno)== false)
            {
                MessageBox.Show("El campo Matricula Alumno no tiene ningun dato. Favor de llenar el campo");
            }
            else
            {
                try
                {
                    solicitud.AsignarProyectos(proyecto1, proyecto2, proyecto3, txtMatriculaAlumno.Text);
                    MessageBox.Show("Solicitud Exitosa.");
                }catch(LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            

        }

        private void BtnEliminarOpcion_Click(object sender, RoutedEventArgs e)
        {
            if(listProyectos.Items.IsEmpty == true)
            {
                MessageBox.Show("No hay proyectos que eliminar de la seleccion.");
                btnEliminarOpcion.IsEnabled = false;
            }
            else
            {
                var seleccion = listProyectos.SelectedIndex;
                if (seleccion != -1)
                {
                    listProyectos.Items.RemoveAt(seleccion);
                    c--;
                    btnAdd.IsEnabled = true;
                }
            }
          
        }
    }
}
