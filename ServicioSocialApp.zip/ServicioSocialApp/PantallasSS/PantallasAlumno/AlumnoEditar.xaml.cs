﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using ServicioSocialApp;
using LogicaDeNegocio.Util;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoEditar.xaml
    /// </summary>
    public partial class AlumnoEditar : Window
    {
        public AlumnoEditar()
        {
            InitializeComponent();
        }

        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            AlumnoPrincipal1 alumnoPrincipal = new AlumnoPrincipal1();
            alumnoPrincipal.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Alumno alumno = new Alumno();
            AlumnoDAO alumnoDAO1 = new AlumnoDAO();
            validarExpresiones validar = new validarExpresiones();
            int c = 0;

            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else if (validar.MatriculaValida(txtMatricula.Text) == false)
            {
                MessageBox.Show("El formato de matricula no es correcto");
            }
            else if (alumnoDAO1.GetMatricula(txtMatricula.Text) == false)
            {
                MessageBox.Show("Escribe la matricula correcta, por favor");
            }
            else
            {
                alumno.matricula = txtMatricula.Text;
                c++;
            }
                   

            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo Electronico no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if(validar.EmailValido(txtCorreo.Text) == false)
                {
                    MessageBox.Show("El formato de correo no es valido.");
                }
                else
                {
                    alumno.correoElectronico = txtCorreo.Text;
                    c++;
                }
                
            }
            if (ValidarCampo(txtContrasena) == false)
            {
                MessageBox.Show("El campo Contraseña no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if(validar.ContrasenaValida(txtContrasena.Text) == false)
                {
                    MessageBox.Show("El formato de contraseña no es valido");
                }
                else
                {
                    alumno.contraseñaAlumno = txtContrasena.Text;
                    c++;
                }
                
            }



            if (c == 3)
            {
                AlumnoDAO alumnoDAO = new AlumnoDAO();

                try
                {
                    alumnoDAO.EditarAlumno(txtMatricula.Text, txtContrasena.Text, txtCorreo.Text);

                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Actualizacion Exitosa.");
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
    }
}
