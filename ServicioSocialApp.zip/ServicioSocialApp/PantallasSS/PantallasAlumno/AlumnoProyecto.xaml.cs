﻿using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoProyecto.xaml
    /// </summary>
    public partial class AlumnoProyecto : Window
    {
        public AlumnoProyecto()
        {
            InitializeComponent();

        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            AlumnoPrincipal1 alumnoPrincipal = new AlumnoPrincipal1();
            alumnoPrincipal.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
    }
}
