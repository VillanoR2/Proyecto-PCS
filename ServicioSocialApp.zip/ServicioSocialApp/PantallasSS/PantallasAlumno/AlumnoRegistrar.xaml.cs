﻿using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Util;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoRegistrar.xaml
    /// </summary>
    public partial class AlumnoRegistrar : Window
    {
        public AlumnoRegistrar()
        {
            InitializeComponent();
            comboLicenciatura.SelectedIndex = 0;
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }

        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }
        private void BtnIniciarSesion_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

        private void BtnRegistrarAlumno_Click(object sender, RoutedEventArgs e)
        {
            Alumno alumno = new Alumno();
            validarExpresiones validar = new validarExpresiones();
            int numCamposValidos = 0;
            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("Formato de nombre no valido");
                }
                else
                {
                    alumno.nombre = txtNombre.Text.ToUpper();
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtApellido) == false)
            {
                MessageBox.Show("El campo Apellido no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtApellido.Text) == false)
                {
                    MessageBox.Show("Formato de apellido no válido");
                }
                else
                {
                    alumno.apellidos = txtApellido.Text.ToUpper();
                    numCamposValidos++;
                }

            }
            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.MatriculaValida(txtMatricula.Text) == false)
                {
                    MessageBox.Show("El campo Matricula no es valido");
                }
                else
                {
                    alumno.matricula = txtMatricula.Text.ToUpper();
                    numCamposValidos++;

                }


            }
            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo Electronico no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.EmailValido(txtCorreo.Text) == false)
                {
                    MessageBox.Show("El correo no tiene un formato valido");
                }
                else
                {
                    alumno.correoElectronico = txtCorreo.Text;
                    numCamposValidos++;
                }

            }
            if (ValidarCampo(txtContrasena) == false)
            {
                MessageBox.Show("El campo Contraseña no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.ContrasenaValida(txtContrasena.Text) == false)
                {
                    MessageBox.Show("El formato no es válido. \nLa contraseña debe contener al menos una mayuscula, tener al menos una minuscula y un carácter especial (!,&,$) ");
                }
                else
                {
                    alumno.contraseñaAlumno = txtContrasena.Text;
                    numCamposValidos++;
                }

            }

            alumno.carreraAlumno = (Carrera)Enum.GetValues(typeof(Carrera)).GetValue(comboLicenciatura.SelectedIndex);


            if (numCamposValidos == 5)
            {
                AlumnoDAO alumnoDAO = new AlumnoDAO();

                try
                {
                    alumnoDAO.RegistrarAlumno(alumno);
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                SolicitudDAO solicitud = new SolicitudDAO();

                try
                {
                    solicitud.RealizarSolicitud(txtMatricula.Text.ToUpper());
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MainWindow main = new MainWindow();
                this.Hide();
                main.Show();
            }
        }

        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtApellido_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }
    }
}

