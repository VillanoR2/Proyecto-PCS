﻿using LogicaDeNegocio.AccesoADatos;
using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para AlumnoPrincipal1.xaml
    /// </summary>
    public partial class AlumnoPrincipal1 : Window
    {
        public AlumnoPrincipal1()
        {
            ProyectoDAO proyectoDAO = new ProyectoDAO();
            InitializeComponent();
            txtNombre.Text = proyectoDAO.ObtenerDatos("P0001");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
            AlumnoEditar alumnoEditar = new AlumnoEditar();
            this.Hide();
            alumnoEditar.Show();
        }

       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            AlumnoProyecto alumnoProyecto = new AlumnoProyecto();
            this.Hide();
            alumnoProyecto.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

        private void TxtNombre_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
