﻿using ServicioSocialApp.PantallasSS.PantallasCoordinador;
using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Modelo.Emun;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Excepciones;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorPrincipal1.xaml
    /// </summary>
    public partial class CoordinadorPrincipal1 : Window
    {
        public CoordinadorPrincipal1()
        {
            InitializeComponent();
            dgdCuentasEnEspera.IsReadOnly = true;
            dataCuentasValidad.IsReadOnly = true;
            dataProyectos.IsReadOnly = true;
            llenarGridProyecto();
            llenarGridAlumnosAsignacion();
            llenarGridAlumnosValidar();

        }

        private void DgdCuentasEnEspera_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            if (this.dgdCuentasEnEspera.Columns != null)
            {
                this.dgdCuentasEnEspera.Columns[0].Visibility = Visibility.Collapsed;
                this.dgdCuentasEnEspera.Columns[2].Visibility = Visibility.Collapsed;
                this.dgdCuentasEnEspera.Columns[4].Visibility = Visibility.Collapsed;
                this.dgdCuentasEnEspera.Columns[7].Visibility = Visibility.Collapsed;
            }
        }

        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                return validar;
            }

            return validar = true;

        }

        public void llenarGridAlumnosValidar()
        {

            SolicitudDAO solicitudDAO = new SolicitudDAO();

            AlumnoDAO alumnodao = new AlumnoDAO();

            if (solicitudDAO.ObtenerEstadoEspera() != EstadoSolicitud.EnEspera)
            {
                btnGuardar.IsEnabled = false;
                btnRechazar.IsEnabled = false;
                txtMatriculaValidar.IsEnabled = false;
               
            }
            else
            {
                btnGuardar.IsEnabled = true;
                btnRechazar.IsEnabled = true;
                txtMatriculaValidar.IsEnabled = true;
                dgdCuentasEnEspera.ItemsSource = alumnodao.MostrarAlumnosSolicitud();
            }
        }

        public void llenarGridAlumnosAsignacion()
        {

            SolicitudDAO solicitudDAO = new SolicitudDAO();


            if (solicitudDAO.ObtenerEstadoEspera() != EstadoSolicitud.Aceptada)
            {   
                btnAsignar.IsEnabled = false;
                txtMatricula.IsEnabled = false;
                txtIdProyecto.IsEnabled = false;
                MessageBox.Show("No existen Solicitudes de alumnos validas aun.");
            }
            else
            {
                btnAsignar.IsEnabled = true;
                txtMatricula.IsEnabled = true;
                txtIdProyecto.IsEnabled = true;
                dataCuentasValidad.ItemsSource = solicitudDAO.MostrarSolicitudes();
            }
        }

        public void llenarGridProyecto()
        {
            List<Proyecto> proyectos = new List<Proyecto>();

            ProyectoDAO proyectoDAO = new ProyectoDAO();

            if (proyectos.Any())
            {

                MessageBox.Show("No existen Proyectos registrados aun.");
            }
            else
            {
                dataProyectos.ItemsSource = proyectoDAO.MostrarProyectos();
            }
        }

        private void BtnProyecto_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorProyecto coordinadorProyecto = new CoordinadorProyecto();
            this.Hide();
            coordinadorProyecto.Show();

        }

        private void BtnCalendario_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorCalendario coordinadorCalendario = new CoordinadorCalendario();
            this.Hide();
            coordinadorCalendario.Show();
        }

        private void BtnInstitucion_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorInstitucion institucion = new CoordinadorInstitucion();
            this.Hide();
            institucion.Show();
        }

        private void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorActualizar actualizar = new CoordinadorActualizar();
            this.Hide();
            actualizar.Show();
        }

        private void BtnEncargado_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorEncargado coordinadorEncargado = new CoordinadorEncargado();
            this.Hide();
            coordinadorEncargado.Show();
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {

            int c = 0;
            if (ValidarCampo(txtMatriculaValidar) == false)
            {
                MessageBox.Show("El campo Matricula de Alumno no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                c++;
            }

                EstadoSolicitud estado = EstadoSolicitud.Aceptada;

                SolicitudDAO solicitud = new SolicitudDAO();

            if (c == 1)
            {
                try
                {
                    solicitud.CambiarEstadoSolicitud(txtMatriculaValidar.Text, estado);
                    
                }catch(LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Alumno validado");
            }
            

        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

        private void BtnMasOpciones_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorTecnico tecnico = new CoordinadorTecnico();
            this.Hide();
            tecnico.Show();
        }

        private void BtnRechazar_Click(object sender, RoutedEventArgs e)
        {
            int c = 0;
            if (ValidarCampo(txtMatriculaValidar) == false)
            {
                MessageBox.Show("El campo Matricula de Alumno no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                c++;
            }

            EstadoSolicitud estado = EstadoSolicitud.Rechazada;

            SolicitudDAO solicitud = new SolicitudDAO();

            if (c == 1)
            {
                try
                {
                    solicitud.CambiarEstadoSolicitud(txtMatriculaValidar.Text, estado);

                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void BtnAsignar_Click(object sender, RoutedEventArgs e)
        {
            int c = 0;

            Asignacion asignacion = new Asignacion();


            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula de Alumno no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                AlumnoDAO alumnoDAO = new AlumnoDAO();
                if (alumnoDAO.GetMatricula(txtMatricula.Text) == true)
                {
                    asignacion.alumnoAsignado = txtMatricula.Text;
                    c++;
                }
                else
                {
                    MessageBox.Show("La matricula no existe. \nFavor de ingresar nuevamente el valor");
                }
            }
            if (ValidarCampo(txtIdProyecto) == false)
            {
                MessageBox.Show("El campo ID Proyecto no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                ProyectoDAO proyectoDAO = new ProyectoDAO();
                if (proyectoDAO.GetIdProyecto(txtIdProyecto.Text)== true)
                {
                    asignacion.proyectoAsignado = txtIdProyecto.Text;
                    c++;
                }
                else
                {
                    MessageBox.Show("El ID no existe. \nFavor de ingresar nuevamente el valor");
                }
                
            }

            if (c == 2)
            {
                AsignacionDAO asignacionDAO = new AsignacionDAO();
                asignacion.estadoAsignado = EstadoServicio.Aceptado;

                try
                {
                    asignacionDAO.RealizarAsignacion(asignacion.alumnoAsignado, asignacion.proyectoAsignado, asignacion.estadoAsignado);
                    MessageBox.Show("Asignacion exitosa.");
                }catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                ProyectoDAO proyecto = new ProyectoDAO();
                proyecto.CalcularVacanates(asignacion.proyectoAsignado);
            }

        }

        private void DgdCuentasEnEspera_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
