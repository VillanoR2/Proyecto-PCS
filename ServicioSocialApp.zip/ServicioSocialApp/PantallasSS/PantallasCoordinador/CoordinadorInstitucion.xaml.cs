﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Util;
using ServicioSocialApp;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorInstitucion.xaml
    /// </summary>
    public partial class CoordinadorInstitucion : Window
    {
        public CoordinadorInstitucion()
        {
            InitializeComponent();
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }

        private bool RestringirCamposNumericos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIONUMEROS = 48;
            int FINALNUMEROS = 57;
 

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIONUMEROS && ascci <= FINALNUMEROS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }
        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            CoordinadorPrincipal1 coordinadorPrincipal = new CoordinadorPrincipal1();
            coordinadorPrincipal.Show();
        }

        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtTelefono_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCamposNumericos(e);
        }

        private void TxtTipo_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);

        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Institucion institucion = new Institucion();
            validarExpresiones validar = new validarExpresiones();

            int numCamposValidos = 0;
            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("El nombre de la institución no es válido");
                }
                else
                {
                    institucion.nombreInstitucion = txtNombre.Text;
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtTelefono) == false)
            {
                MessageBox.Show("El campo Telefono no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.TelefonoValido(txtTelefono.Text) == false)
                {
                    MessageBox.Show("El formato de telefono no es valido");
                }
                else
                {
                    institucion.telefonoInstitucion = txtTelefono.Text;
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtTipo) == false)
            {
                MessageBox.Show("El campo Tipo de institución no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtTipo.Text) == false)
                {
                    MessageBox.Show("El formato del tipo de institución no es correcto");
                }
                else
                {
                    institucion.tipoInstitucion = txtTipo.Text;
                    numCamposValidos++;
                }

            }
            if (ValidarCampo(txtDireccion) == false)
            {
                MessageBox.Show("El campo dirección no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.DomicilioValido(txtDireccion.Text) == false)
                {
                    MessageBox.Show("El formato de la dirección no es válido");
                }
                else
                {
                    institucion.direccion = txtDireccion.Text;
                    numCamposValidos++;
                }

            }

            if (numCamposValidos == 4)
            {
                InstitucionDAO institucionDAO = new InstitucionDAO();

                try
                {
                    institucionDAO.RegistrarInstitucion(institucion);
                    MessageBox.Show("Registro exitoso");
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                


            }

        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }
    }
}

