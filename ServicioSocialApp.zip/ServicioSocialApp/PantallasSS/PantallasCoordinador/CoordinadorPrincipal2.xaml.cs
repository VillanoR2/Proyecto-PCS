﻿using ServicioSocialApp;
using ServicioSocialApp.PantallasSS.PantallasCoordinador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorPrincipal2.xaml
    /// </summary>
    public partial class CoordinadorPrincipal2 : Window
    {
        public CoordinadorPrincipal2()
        {
            InitializeComponent();
        }

        private void BtnMasOpciones_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorTecnico tecnico = new CoordinadorTecnico();
            this.Hide();
            tecnico.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorConsultaProyectos coordinadorConsulta = new CoordinadorConsultaProyectos();
            this.Hide();
            coordinadorConsulta.Show();
        }

        private void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorActualizar coordinadorActualizar = new CoordinadorActualizar();
            this.Hide();
            coordinadorActualizar.Show();
        }

        private void BtnMasOpcionesAlumno_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorAlumno coordinadorAlumno = new CoordinadorAlumno();
            this.Hide();
            coordinadorAlumno.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CoordinadorCalendario calendario = new CoordinadorCalendario();
            this.Hide();
            calendario.Show();
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Hide();
            main.Show();

        }
    }
}
