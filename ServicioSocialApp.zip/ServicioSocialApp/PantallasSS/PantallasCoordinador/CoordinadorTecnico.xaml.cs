﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Excepciones;
using ServicioSocialApp;
using ServicioSocialApp.PantallasSS.PantallasCoordinador;
using LogicaDeNegocio.Util;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorTecnico.xaml
    /// </summary>
    public partial class CoordinadorTecnico : Window
    {
        public CoordinadorTecnico()
        {
            InitializeComponent();
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }
        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorPrincipal1 coordinadorPrincipal1 = new CoordinadorPrincipal1();
            this.Hide();
            coordinadorPrincipal1.Show();
        }

        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }
        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtApellidos_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);

        }

        private void BtnEditarTec_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorTecnicoEditar coordinadorTecnicoEditar = new CoordinadorTecnicoEditar();
            this.Hide();
            coordinadorTecnicoEditar.Show();
        }

        private void BtnEliminarTecnico_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRegistrarTec_Click(object sender, RoutedEventArgs e)
        {
            TecnicoAcademico tecnico = new TecnicoAcademico();
            validarExpresiones validar = new validarExpresiones();
            int c = 0;
            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("El formato de nombre no es valido");
                }
                else
                {
                    tecnico.nombre = txtNombre.Text;
                    c++;
                }

            }
            if (ValidarCampo(txtApellidos) == false)
            {
                MessageBox.Show("El campo Apellido no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtApellidos.Text) == false)
                {
                    MessageBox.Show("El formato del apellido no es valido");
                }
                else
                {
                    tecnico.apellidos = txtApellidos.Text;
                    c++;
                }

            }
            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.MatriculaValida(txtMatricula.Text) == false)
                {
                    MessageBox.Show("El formato de matricula no es vàlido. \nFormato deseado T00000000");
                }
                else
                {
                    tecnico.numPersonalTecnico = txtMatricula.Text;
                    c++;
                }

            }
            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo Electronico no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.EmailValido(txtCorreo.Text) == false)
                {
                    MessageBox.Show("El formato de correo no es vàlido");
                }
                else
                {
                    tecnico.correoElectronico = txtCorreo.Text;
                    c++;
                }

            }
            if (ValidarCampo(txtContrasena) == false)
            {
                MessageBox.Show("El campo Contraseña no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.ContrasenaValida(txtContrasena.Text) == false)
                {
                    MessageBox.Show("La contraseña no es valida. \nDebe tener al menos una mayuscula, una minuscula, un numero y un caracter");
                }
                else
                {
                    tecnico.contraseñaTecnico = txtContrasena.Text;
                    c++;
                }

            }
            if (ValidarCampo(txtMatriculaCoordinador) == false)
            {
                MessageBox.Show("El campo matricula coordinador no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                CoordinadorDAO coordinadorDAO = new CoordinadorDAO();
                if (validar.MatriculaValida(txtMatriculaCoordinador.Text) == false)
                {
                    MessageBox.Show("El formato de matricula no es vàlido. \nFormato deseado T00000000");
                }

                else if (coordinadorDAO.GetIdCoordinador(txtMatriculaCoordinador.Text) == true)
                {
                    tecnico.auxuliaA = txtMatriculaCoordinador.Text;
                    c++;
                }
                else
                {
                    MessageBox.Show("La Matricula ingresada no es valida.");
                }

            }


            if (c == 6)
            {
                TecnicoDAO tecnicoDAO = new TecnicoDAO();

                try
                {
                    tecnicoDAO.RegistrarTecnico(tecnico);
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Registro exitoso");



            }

        }
    }
}
