﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Util;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorProyecto.xaml
    /// </summary>
    public partial class CoordinadorProyecto : Window
    {
        public CoordinadorProyecto()
        {
            InitializeComponent();
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }
        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorPrincipal1 coordinadorPrincipal = new CoordinadorPrincipal1();
            this.Hide();
            coordinadorPrincipal.Show();
        }

        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtMaxAlumnos_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Proyecto proyecto = new Proyecto();
            InstitucionDAO institucion = new InstitucionDAO();
            ProyectoDAO proyectoDao = new ProyectoDAO();
            EncargadoDAO encargado = new EncargadoDAO();
            validarExpresiones validar = new validarExpresiones();
            int numCamposValidos = 0;
            if (ValidarCampo(txtID) == false)
            {
                MessageBox.Show("El campo ID Proyecto no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {

                if (proyectoDao.GetIdProyecto(txtID.Text) == true)
                {
                    MessageBox.Show("El ID ya existe.");
                }
                else
                {
                    if (validar.IdProyectoValido(txtID.Text) == false)
                    {
                        MessageBox.Show("El ID del proyecto no es valido.\n EL formato deseado es P0000");
                    }
                    else
                    {
                        proyecto.idProyecto = txtID.Text;
                        numCamposValidos++;
                    }
                }
            }
            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("El formato del nombre es invalido");
                }
                else
                {
                    proyecto.nombreProyecto = txtNombre.Text;
                    numCamposValidos++;
                }

            }
            if (ValidarCampo(txtMaxAlumnos) == false)
            {
                MessageBox.Show("El campo Alumnos Maximos no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.MaxAlumnosValido(txtMaxAlumnos.Text) == false)
                {
                    MessageBox.Show("El maximo de alumnos ingresado no es valido");
                }
                else
                {
                    proyecto.maxAlumno = Convert.ToInt32(txtMaxAlumnos.Text);
                    numCamposValidos++;
                }

            }
            if (ValidarCampo(txtInstitucion) == false)
            {
                MessageBox.Show("El campo Institucion no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtInstitucion.Text) == false)
                {
                    MessageBox.Show("El formato del nombre de institución no es válido");
                }



                else if (institucion.GetNombreInsitucion(txtInstitucion.Text) == true)
                {
                    proyecto.perteneceA = txtInstitucion.Text;
                    numCamposValidos++;
                }
                else
                {
                    MessageBox.Show("Se ingreso un nombre de institucion no valido.\nPorfavor ingrese un nombre valido.");
                }

            }
            if (ValidarCampo(txtEncargado) == false)
            {
                MessageBox.Show("El campo Encargado no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.MatriculaValida(txtEncargado.Text) == false)
                {
                    MessageBox.Show("El formato del id del encargado es invalido");
                }


                else if (encargado.GetIdEncargado(txtEncargado.Text) == true)
                {
                    proyecto.dirigidoPor = txtEncargado.Text;
                    numCamposValidos++;
                }
                else
                {
                    MessageBox.Show("El ID de encargado no es valido. \nFavor ingrese un ID valido.");
                }
            }

            if (numCamposValidos == 5)
            {

                try
                {
                    proyectoDao.RegistrarProyeto(proyecto);
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Registro exitoso");

            }
        }
    }
}
