﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using WpfApp1;

namespace ServicioSocialApp.PantallasSS.PantallasCoordinador
{
    /// <summary>
    /// Lógica de interacción para CoordinadorTecnicoEditar.xaml
    /// </summary>
    public partial class CoordinadorTecnicoEditar : Window
    {
        public CoordinadorTecnicoEditar()
        {
            InitializeComponent();
        }


        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorTecnico coordinadorTecnico = new CoordinadorTecnico();
            this.Hide();
            coordinadorTecnico.Show();
        }

        private void BtnActualizar_Click(object sender, RoutedEventArgs e)
        {
            TecnicoAcademico tecnico = new TecnicoAcademico();
            int numCamposValidos = 0;

            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                tecnico.numPersonalTecnico = txtMatricula.Text;
                numCamposValidos++;
            }

            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo Electronico no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                tecnico.correoElectronico = txtCorreo.Text;
                numCamposValidos++;
            }
            if (ValidarCampo(txtContrasena) == false)
            {
                MessageBox.Show("El campo Contraseña no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                tecnico.contraseñaTecnico = txtContrasena.Text;
                numCamposValidos++;
            }



            if (numCamposValidos == 3)
            {
                CoordinadorDAO coordinadorDAO = new CoordinadorDAO();

                try
                {
                    coordinadorDAO.EditarCoordinador(txtMatricula.Text, txtContrasena.Text, txtCorreo.Text);

                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                MessageBox.Show("Actualizacion Exitosa.");
                CoordinadorTecnico coordinadorTecnico = new CoordinadorTecnico();
                this.Hide();
                coordinadorTecnico.Show();
            }

        }
    }
}
