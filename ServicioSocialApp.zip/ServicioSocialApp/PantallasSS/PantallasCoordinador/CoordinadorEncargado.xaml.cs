﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1;
using LogicaDeNegocio.AccesoADatos;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Util;

namespace ServicioSocialApp.PantallasSS.PantallasCoordinador
{
    /// <summary>
    /// Lógica de interacción para CoordinadorEncargado.xaml
    /// </summary>
    public partial class CoordinadorEncargado : Window
    {
        public CoordinadorEncargado()
        {
            InitializeComponent();
            btnregistrarInstitucion.IsEnabled = false;
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if (e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }
        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }
        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorPrincipal1 coordinadorPrincipal = new CoordinadorPrincipal1();
            this.Hide();
            coordinadorPrincipal.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Encargado encargado = new Encargado();
            validarExpresiones validar = new validarExpresiones();
            int camposValidos = 0;

            if (ValidarCampo(txtID) == false)
            {
                MessageBox.Show("El campo ID no tiene ningún dato");
            }
            else
            {
                if (validar.MatriculaValida(txtID.Text) == false)
                {
                    MessageBox.Show("El ID no es vàlido. \nEl formato deseado es E00000000");
                }
                else
                {
                    encargado.idEncargado = txtID.Text;
                    camposValidos++;
                }

            }
            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");

            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("El formato de nombre no es válido");
                }
                else
                {
                    encargado.nombre = txtNombre.Text;
                    camposValidos++;
                }

            }
            if (ValidarCampo(txtApellido) == false)
            {
                MessageBox.Show("El campo Apellido no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtApellido.Text) == false)
                {
                    MessageBox.Show("El formato del apellido no es válido.");
                }
                else
                {
                    encargado.apellidos = txtApellido.Text;
                    camposValidos++;
                }

            }
            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.EmailValido(txtCorreo.Text) == false)
                {
                    MessageBox.Show("El formato de email no es valido");
                }
                else
                {
                    encargado.correoElectronico = txtCorreo.Text;
                    camposValidos++;
                }

            }
            if (ValidarCampo(txtInstitucion) == false)
            {
                MessageBox.Show("El campo Institución no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                InstitucionDAO institucionDAO = new InstitucionDAO();

                if (institucionDAO.GetNombreInsitucion(txtInstitucion.Text) == true)
                {
                    encargado.perteneceA = txtInstitucion.Text;
                    camposValidos++;
                }
                else
                {
                    MessageBox.Show("No existe institucion registrada con ese nombre. \nPorfavor registre una nueva.");
                    btnregistrarInstitucion.IsEnabled = true;
                }
            }


            if (camposValidos == 5)
            {
                EncargadoDAO encargadoDAO = new EncargadoDAO();

                try
                {
                    encargadoDAO.RegistrarEncargado(encargado);
                    MessageBox.Show("El encargado se registró exitosamente");
                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
     
                }

            }
        }

        private void BtnregistrarInstitucion_Click(object sender, RoutedEventArgs e)
        {
            CoordinadorInstitucion coordinadorInstitucion = new CoordinadorInstitucion();
            this.Hide();
            coordinadorInstitucion.Show();
        }

        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtApellido_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }
    }
}

