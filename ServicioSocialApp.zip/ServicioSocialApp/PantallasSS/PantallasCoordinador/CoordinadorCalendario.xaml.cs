﻿using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;
using ServicioSocialApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para CoordinadorCalendario.xaml
    /// </summary>
    public partial class CoordinadorCalendario : Window
    {
        public CoordinadorCalendario()
        {
            InitializeComponent();
            comboDocumentos.SelectedIndex = 0;
        }

        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                return validar;
            }

            return validar = true;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            CoordinadorPrincipal1 coordinadorPrincipal = new CoordinadorPrincipal1();
            coordinadorPrincipal.Show();
        }

        private void BtnRegresar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            this.Hide();
            mainWindow.Show();
        }

        private void BtnCalendario_Click(object sender, RoutedEventArgs e)
        {
           
        }
    }
}
