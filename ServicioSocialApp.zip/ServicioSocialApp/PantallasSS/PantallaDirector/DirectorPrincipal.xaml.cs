﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos;
using ServicioSocialApp;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para DirectorPrincipal.xaml
    /// </summary>
    public partial class DirectorPrincipal : Window
    {
        public DirectorPrincipal()
        {
            InitializeComponent();
            dtgCoordinadores.IsReadOnly = true;
            LlenarGrid();
        }

        public void LlenarGrid()
        {
            List<Coordinador> coordinadores = new List<Coordinador>();

            CoordinadorDAO coordinador = new CoordinadorDAO();
            
            if (coordinadores.Any())
            {
                MessageBox.Show("No existen coordinadores aun.");
            }
            else
            {
                dtgCoordinadores.ItemsSource = coordinador.MostrarCoordinadores();
            }
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Hide();
            main.Show();

        }

        private void BtnRegistrarCoor_Click(object sender, RoutedEventArgs e)
        {
            DirectorCoordinador directorCoordinador = new DirectorCoordinador();
            this.Hide();
            directorCoordinador.Show();
        }

        private void BtnEliminarCoor_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
