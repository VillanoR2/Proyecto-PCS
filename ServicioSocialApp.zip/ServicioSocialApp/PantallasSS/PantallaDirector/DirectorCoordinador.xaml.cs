﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;
using LogicaDeNegocio.AccesoADatos;
using ServicioSocialApp;
using LogicaDeNegocio.Util;

namespace WpfApp1
{
    /// <summary>
    /// Lógica de interacción para DirectorCoordinador.xaml
    /// </summary>
    public partial class DirectorCoordinador : Window
    {
        

        public DirectorCoordinador()
        {
            InitializeComponent();
            cmbCarreraCordinador.SelectedIndex = 0;
        }

        private bool RestringirCampos(TextCompositionEventArgs e)
        {
            bool resultado;
            int INICIOMAYUSCULAS = 65;
            int FINALMAYUSCULAS = 90;
            int INICIOMINUSCULAS = 97;
            int FINMINUSCULAS = 122;

            int ascci = Convert.ToInt32(Convert.ToChar(e.Text));
            if (ascci >= INICIOMAYUSCULAS && ascci <= FINALMAYUSCULAS || ascci >= INICIOMINUSCULAS && ascci <= FINMINUSCULAS)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
            if(e.Handled == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }

            return resultado;

        }
        private bool ValidarCampo(TextBox box)
        {
            bool validar = false;
            if (box.Text == "")
            {
                validar = false;
            }
            else
            {
                validar = true;
            }
            return validar;

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TxtCorreo_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TxtNombre_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);
        }

        private void TxtApellido_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            RestringirCampos(e);    
        }

        private void BtnRegistrarCoordinador_Click(object sender, RoutedEventArgs e)
        {
            Coordinador coordinador = new Coordinador();
            validarExpresiones validar = new validarExpresiones();

            int numCamposValidos = 0;

            if (ValidarCampo(txtNombre) == false)
            {
                MessageBox.Show("El campo Nombre no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtNombre.Text) == false)
                {
                    MessageBox.Show("El formato del nombre es incorrecto");
                }
                else
                {
                    if (validar.NombreValido(txtNombre.Text) == false)
                    {
                        MessageBox.Show("El formato del nombre es incorrecto");
                    }
                    else
                    {
                        coordinador.nombre = txtNombre.Text;
                        numCamposValidos++;
                    }
                }

            }
            if (ValidarCampo(txtApellido) == false)
            {
                MessageBox.Show("El campo Apellido(s) no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.NombreValido(txtApellido.Text) == false)
                {
                    MessageBox.Show("El formato del apellido es incorrecto");
                }
                else
                {
                    coordinador.apellidos = txtApellido.Text;
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtMatricula) == false)
            {
                MessageBox.Show("El campo Matricula no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.MatriculaValida(txtMatricula.Text) == false)
                {
                    MessageBox.Show("El formato de la matricula es incorrecto. /nEl formato deseado es C000000000");
                }
                else
                {
                    coordinador.numPersonalCoordinador = txtMatricula.Text;
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtCorreo) == false)
            {
                MessageBox.Show("El campo Correo Electronico no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.EmailValido(txtCorreo.Text) == false)
                {
                    MessageBox.Show("El formato del correo es inválido. \nEl formato deseado es correoalgo@dominio.com");
                }
                else
                {
                    coordinador.correoElectronico = txtCorreo.Text;
                    numCamposValidos++;
                }
            }
            if (ValidarCampo(txtContraseña) == false)
            {
                MessageBox.Show("El campo Contraseña no tiene ningun dato. \nFavor de llenar el campo.");
            }
            else
            {
                if (validar.ContrasenaValida(txtContraseña.Text) == false)
                {
                    MessageBox.Show("El formato de la contraseña es incorrecto.\nDebe contener al menos una mayuscula, una minuscula y un caracter especial");

                }
                else
                {
                    coordinador.contraseñaCoordinador = txtContraseña.Text;
                    numCamposValidos++;
                }
            }

            coordinador.carreraCoordinar = (Carrera)Enum.GetValues(typeof(Carrera)).GetValue(cmbCarreraCordinador.SelectedIndex);

            if (numCamposValidos == 5)
            {
                CoordinadorDAO coordinadorDAO = new CoordinadorDAO();

                try
                {
                    coordinadorDAO.RegistrarCoordinador(coordinador);

                }
                catch (LogicException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                DirectorPrincipal principal = new DirectorPrincipal();
                this.Hide();
                principal.Show();
            }
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Hide();
            main.Show();
        }
    }
}
