﻿using System;
using System.Data.SqlClient;
using System.Configuration;



namespace BaseDatos
{
    /// <summary>
    /// Clase para acceso a la base de datos.
    /// Contiene metodos para obtener y cerrar una conexión con base de datos.
    /// </summary>
    public class ConexionBaseDatos
    {
        private SqlConnection conexionServicioSocialBD;

        private String connectionString;

        public ConexionBaseDatos()
        {

                connectionString = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

                conexionServicioSocialBD = new SqlConnection(connectionString);

        }
        /// <summary>
        /// Obtiene la conexión con la base de datos.
        /// </summary>
        /// <returns>Una conexión con la base de datos</returns>
        public SqlConnection GetConnection()
        {
            return conexionServicioSocialBD;
        }
        /// <summary>
        /// Cierra la conexión con la base de datos.
        /// </summary>
        public void CloseConnection()
        {
            if (conexionServicioSocialBD != null)
            {
                if (conexionServicioSocialBD.State == System.Data.ConnectionState.Open)
                {
                    conexionServicioSocialBD.Close();
                }
            }
        }
    }
}
