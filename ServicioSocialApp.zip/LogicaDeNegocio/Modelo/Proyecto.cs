﻿using System;
using System.Collections.Generic;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Proyecto
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Proyecto
    {
        public String idProyecto { get; set; }

        public int maxAlumno { get; set; }

        public int vacantes { get; set; }

        public String nombreProyecto { get; set; }

        public EstadoProyecto estadoP { get; set; }

        public String perteneceA { get; set; }

        public String dirigidoPor { get; set; }

        private List<Proyecto> proyectos = new List<Proyecto>();

    }

}
