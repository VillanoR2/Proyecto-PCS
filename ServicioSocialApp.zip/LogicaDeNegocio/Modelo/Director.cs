﻿using System;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Director.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// <para>Hereda de <see cref="Persona"/>.</para>
    /// </summary>
    public class Director : Persona
    {
        public String contraseñaDirector { get; set; }

        public int numPersonal { get; set; }
   
    }
}
