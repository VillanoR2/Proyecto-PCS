﻿using System;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Reporte
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Reporte
    {
        public DateTime fechaEntrega { get; set; }

        public int horasRegistradas { get; set; }

        public int numeroReporte { get; set; }

        public int idReporte { get; set; }
    }
}
