﻿using System;


namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase TecnicoAcademico.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// <para>Hereda de <see cref="Persona"/>.</para>
    /// </summary>
    public class TecnicoAcademico : Persona
    {
        public String contraseñaTecnico { get; set; }

        public String numPersonalTecnico {get; set;}

        public String auxuliaA { get; set; }

    }
}
