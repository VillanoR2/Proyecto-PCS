﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Expediente.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Expediente
    {
        public int idExpediente { get; set; }

        public Documento documentoExpediente { get; set; }

        public Reporte reporteExpediente { get; set; }
    }

}
