﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaDeNegocio.Modelo
{
   public class Persona
    {
        public String nombre { get; set; }

        public String apellidos { get; set; }

        public String correoElectronico { get; set; }

        public String GetNombreCompleto()
        {
            return nombre + " " + apellidos;
        }
    }
}
