﻿using System;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Coordinador.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// <para>Hereda de <see cref="Persona"/>.</para>
    /// </summary>
    public class Coordinador : Persona
    {
        public String contraseñaCoordinador { get; set; }

        public String numPersonalCoordinador { get; set; }

        public Carrera carreraCoordinar { get; set; }
        
    }
}
