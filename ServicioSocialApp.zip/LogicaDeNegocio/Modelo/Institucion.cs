﻿using System;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Institucion.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Institucion
    {

        public String direccion { get; set; }

        public String nombreInstitucion { get; set; }

        public String telefonoInstitucion { get; set; }

        public String tipoInstitucion { get; set; }
    }
}
