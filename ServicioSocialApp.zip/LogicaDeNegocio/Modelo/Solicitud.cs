﻿using System;
using System.Collections.Generic;
using LogicaDeNegocio.Modelo.Emun;


namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Solicitud.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Solicitud
    {
        public EstadoSolicitud estadoDeSolicitud { get; set; }

        public String solicitadoPor { get; set; }

        public String proyecto1 { get; set; }

        public String proyecto2 { get; set; }

        public String proyecto3 { get; set; }

        public List<Proyecto> proyectosSolicitud = new List<Proyecto>();
    }

}
