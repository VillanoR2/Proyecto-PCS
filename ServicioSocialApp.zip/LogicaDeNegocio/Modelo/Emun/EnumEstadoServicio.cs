﻿using System.ComponentModel;
using LogicaDeNegocio.Util;

namespace LogicaDeNegocio.Modelo.Emun
{
    /// <summary>
    /// Enumerador de estado de servicio
    /// </summary>
    [TypeConverter(typeof(EnumTypeConverter))]
    public enum EstadoServicio
    {
        /// <summary>
        /// Estado de servicio en espera
        /// </summary>
        [Description("En espera")]
        Espera,

        /// <summary>
        /// Estado de servicio aceptado
        /// </summary>
        [Description("Aceptado")]
        Aceptado,

        /// <summary>
        /// Estado de servicio rechazado
        /// </summary>
        [Description("Rechazado")]
        Rechazado,

        /// <summary>
        /// Estado de servicio baja
        /// </summary>
        [Description("Baja")]
        Baja
    }
}
