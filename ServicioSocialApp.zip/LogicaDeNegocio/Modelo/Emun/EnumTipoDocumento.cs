﻿using LogicaDeNegocio.Util;
using System.ComponentModel;

namespace LogicaDeNegocio.Modelo.Emun
{
    /// <summary>
    /// Enumerador de tipo de documento
    /// </summary>
    [TypeConverter(typeof(EnumTypeConverter))]
    public enum TipoDocumento
    {
        /// <summary>
        /// Tipo de documento Carta de liberacion
        /// </summary>
        [Description("Carta de liberación")]
        CartaLiberacion,

        /// <summary>
        /// Tipo de documento Carta de Aceptacion
        /// </summary>
        [Description("Carta de Aceptacion")]
        CartaAceptacion,

        /// <summary>
        /// Tipo de documento Registro y Plan de Actividades
        /// </summary>
        [Description("Registro y Plan de Actividades")]
        RegistroYPlanDeActividades,

        /// <summary>
        /// Tipo de documento Carta de autorizacion
        /// </summary>
        [Description("Carta de asignación")]
        CartaDeAsignacion,

    }
}
