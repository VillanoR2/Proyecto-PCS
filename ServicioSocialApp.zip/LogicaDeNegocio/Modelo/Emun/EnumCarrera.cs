﻿using System.ComponentModel;
using LogicaDeNegocio.Util;

namespace LogicaDeNegocio.Modelo.Emun
{
        /// <summary>
        /// Enumerador de Licenciatura
        /// </summary>
        [TypeConverter(typeof(EnumTypeConverter))]
        public enum Carrera
        {
            /// <summary>
            /// Licenciatura en Ingenieria de Software
            /// </summary>
            [Description("Ingeniería de Software")]
            IngenieriaDeSoftware,

            /// <summary>
            /// Licenciatura en Redes y Servicios de Computo
            /// </summary>
            [Description("Redes y Servicios de Cómputo")]
            RedesyServiciosDeComputo,

            /// <summary>
            /// Licenciatura Tecnologias Computacionales
            /// </summary>
            [Description("Tecnologías Computacionales")]
            TecnologiasComputacionales

        }
    
}
