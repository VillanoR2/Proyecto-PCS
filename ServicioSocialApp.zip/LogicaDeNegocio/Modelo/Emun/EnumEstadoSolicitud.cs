﻿using System.ComponentModel;
using LogicaDeNegocio.Util;

namespace LogicaDeNegocio.Modelo.Emun
{
    /// <summary>
    /// Enumerador de estado de solicitud
    /// </summary>
    [TypeConverter(typeof(EnumTypeConverter))]
    public enum EstadoSolicitud
    {
        /// <summary>
        /// Estado de solicitud en espera
        /// </summary>
        [Description("En Espera")]
        EnEspera,

        /// <summary>
        /// Estado de solicitud aceptada
        /// </summary>
        [Description("Aceptada")]
        Aceptada,

        /// <summary>
        /// Estado de solicitud rechazada
        /// </summary>
        [Description("Rechazada")]
        Rechazada
    }
}
