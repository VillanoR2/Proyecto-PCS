﻿using LogicaDeNegocio.Util;
using System.ComponentModel;

namespace LogicaDeNegocio.Modelo.Emun
{
    /// <summary>
    /// Enumerador de estado de proyecto
    /// </summary>
    [TypeConverter(typeof(EnumTypeConverter))]
    public enum EstadoProyecto
    {
        /// <summary>
        /// Estado de proyecto Asignado
        /// </summary>
        [Description("Asignado")]
        Asignado,

        /// <summary>
        /// Estado de proyecto en espera
        /// </summary>
        [Description("En espera")]
        EnEspera,

    }
}
