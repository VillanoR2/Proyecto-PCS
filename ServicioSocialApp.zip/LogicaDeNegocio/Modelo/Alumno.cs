﻿using LogicaDeNegocio.Modelo.Emun;
using System;
using System.Collections.Generic;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Alumno.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// <para>Hereda de <see cref="Persona"/>.</para>
    /// </summary>

    public class Alumno : Persona
    {
        public String contraseñaAlumno { get; set; }

        public String matricula { get; set; }

        public Carrera carreraAlumno { get; set; }

        public EstadoSolicitud estado { get; set; }

        public EstadoServicio servicio { get; set; }

        private List<Alumno> alumnos = new List<Alumno>();
      
    }

}
