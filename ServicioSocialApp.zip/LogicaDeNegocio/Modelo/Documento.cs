﻿using System;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.Modelo
{
    /// <summary>
    /// Clase Documento.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Documento
    {
        public String idDocumento { get; set; }

        public String nombreDocumento { get; set; }

        public TipoDocumento tipoDocumento { get; set; }

        public DateTime fechaEntrega { get; set; }
    }
}
