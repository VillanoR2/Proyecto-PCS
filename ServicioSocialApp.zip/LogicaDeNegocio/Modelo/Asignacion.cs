﻿using LogicaDeNegocio.Modelo.Emun;
using System;

namespace LogicaDeNegocio.Modelo
{

    /// <summary>
    /// Clase Asignacion.
    /// Contiene todos los atributos para realizar operaciones con la base de datos.
    /// </summary>
    public class Asignacion
    {
        public int horas { get; set; }

        public  EstadoServicio estadoAsignado {get; set;}

        public String alumnoAsignado { get; set; }

        public String proyectoAsignado { get; set; }
    }

}
