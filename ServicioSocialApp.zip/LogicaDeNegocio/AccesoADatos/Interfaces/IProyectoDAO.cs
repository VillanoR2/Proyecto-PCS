﻿using LogicaDeNegocio.Modelo;
using System;
using System.Collections.Generic;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IProyectoDAO
    {
        bool RegistrarProyeto(Proyecto proyecto);

        bool CalcularVacanates(String Proyecto);

        void CambiarEstadoProyecto(Proyecto estadoProyecto);

        List<Proyecto> MostrarProyectos();

        bool GetIdProyecto(String proyecto);
    }
}
