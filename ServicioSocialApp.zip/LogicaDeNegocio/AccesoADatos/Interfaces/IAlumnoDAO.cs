﻿using LogicaDeNegocio.Modelo;
using System.Collections.Generic;
using System;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IAlumnoDAO
    {
        bool RegistrarAlumno(Alumno alumno);

        bool EditarAlumno(String matricula, String contraseña, String correo);

        List<Alumno> MostrarAlumnosAvance(Carrera carrera);

        List<Alumno> MostrarAlumnosSolicitud();

        bool GetMatricula(String alumno);

    }
}
