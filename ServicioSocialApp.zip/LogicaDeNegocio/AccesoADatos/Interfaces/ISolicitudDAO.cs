﻿using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;
using System;
using System.Collections.Generic;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface ISolicitudDAO
    {
        bool CambiarEstadoSolicitud(String matricula, EstadoSolicitud estado);

        bool RealizarSolicitud(String alumno);

        bool AsignarProyectos(String proyecto1, String proyecto2, String proyecto3, String id);

        EstadoSolicitud ObtenerEstado(String alumno);

        EstadoSolicitud ObtenerEstadoEspera();

        List<Solicitud> MostrarSolicitudes();
    }
}
