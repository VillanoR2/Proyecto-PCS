﻿using LogicaDeNegocio.Modelo;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IExpedienteDAO
    {
        bool AsignarFechaADocumento(Documento documento);

        bool EditarFechaADocumento(Documento documento);


    }
}
