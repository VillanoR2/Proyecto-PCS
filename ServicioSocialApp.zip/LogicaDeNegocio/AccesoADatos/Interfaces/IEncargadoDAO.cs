﻿using LogicaDeNegocio.Modelo;
using System;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IEncargadoDAO
    {
        bool RegistrarEncargado(Encargado encargado);

        bool GetIdEncargado(String encargado);
    }
}
