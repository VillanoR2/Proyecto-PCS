﻿using LogicaDeNegocio.Modelo;
using System;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface ITecnicoDAO
    {
        bool RegistrarTecnico(TecnicoAcademico tecnico);

        bool DarBajaTecnico(String matricula);

        bool EditarTecnico(String matricula, String correo, String contraseña);
    }
}
