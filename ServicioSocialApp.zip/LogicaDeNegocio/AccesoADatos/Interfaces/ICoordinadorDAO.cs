﻿using LogicaDeNegocio.Modelo;
using System;
using System.Collections.Generic;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface ICoordinadorDAO
    {

        bool RegistrarCoordinador(Coordinador coordinador);

        bool DarBajaCoordinador(String matricula);

        bool EditarCoordinador(String matricula, String contraseña, String correo);

        List<Coordinador> MostrarCoordinadores();

        bool GetIdCoordinador(String id);

    }
}
