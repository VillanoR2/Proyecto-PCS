﻿using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;
using System;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IAsignacionDAO
    {
        int ActualizarHoras(int horas);

        bool CambiarEstadoBaja();

        bool RealizarAsignacion(String id, String proyecto, EstadoServicio estado);

        EstadoServicio ObtenerEstado(String alumno);
    }
}
