﻿using LogicaDeNegocio.Modelo;
using System;

namespace LogicaDeNegocio.AccesoADatos.Interfaces
{
    interface IInstitucionDAO
    {
        bool RegistrarInstitucion(Institucion institucion);

        bool GetNombreInsitucion(String nombre);
    }
}
