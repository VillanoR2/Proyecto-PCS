﻿using BaseDatos;
using System.Data.SqlClient;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Excepciones;
using System;

namespace LogicaDeNegocio.AccesoADatos
{
    public class EncargadoDAO : IEncargadoDAO
    {
        /// <summary>
        /// Reliza una insercion de datos de un <see cref="Encargado"/>.
        /// </summary>
        /// <param name="Encargado"><see cref="Encargado"/>.</param>
        /// <returns>Si la inserción fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool RegistrarEncargado(Encargado encargado)
        {
            bool encargadoGuardado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Encargado(ID_Encargado,Nombres, Apellidos, CorreoElectronico, Institucion) values(@id,@nombre, @apellido, @correo, @institucion)", connection);
                {
                    command.Transaction = transaction;

                    command.Parameters.Add(new SqlParameter("id", encargado.idEncargado));
                    command.Parameters.Add(new SqlParameter("nombre", encargado.nombre));
                    command.Parameters.Add(new SqlParameter("apellido", encargado.apellidos));
                    command.Parameters.Add(new SqlParameter("correo", encargado.correoElectronico));
                    command.Parameters.Add(new SqlParameter("institucion", encargado.perteneceA));

                    try
                    {
                        command.ExecuteNonQuery();
                        transaction.Commit();
                        encargadoGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            encargadoGuardado = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ExcepcionesLogicas.LlaveDuplicada);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            encargadoGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ExcepcionesLogicas.ValorFueraDeRango);
                        }
                        else
                        {
                            transaction.Rollback();
                            encargadoGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ExcepcionesLogicas.FallaGeneral);
                        }
                    }

                }
                conexionBaseDatos.CloseConnection();
            }

            return encargadoGuardado;
        }

        /// <summary>
        /// Recupera una lista de matriculas de encargados.
        /// </summary>
        /// <param name="Id"><see cref="String"/>.</param>
        /// <returns>Si la recuperacion es exitosa.</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool GetIdEncargado(String id)
        {
            bool idObtenida = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT ID_Encargado FROM Encargado WHERE ID_Encargado = @id", connection))
                {
                    command.Parameters.Add(new SqlParameter("id", id));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Proyecto proyecto = new Proyecto();
                        proyecto.idProyecto = reader["ID_Encargado"].ToString();
                        idObtenida = true;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            return idObtenida;
        }

    }
}
