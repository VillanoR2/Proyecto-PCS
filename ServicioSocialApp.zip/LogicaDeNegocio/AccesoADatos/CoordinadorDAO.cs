﻿using System.Collections.Generic;
using System.Data.SqlClient;
using BaseDatos;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using System;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.AccesoADatos
{
    public class CoordinadorDAO : ICoordinadorDAO
    {
        /// <summary>
        /// Se elimina a un coordinador.
        /// </summary>
        /// <param name="Matricula"><see cref="String"/>.</param>
        /// <returns>Si la eliminacion fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQLException detecta una excepcion</exception>
        public bool DarBajaCoordinador(String matricula)
        {
            bool bajaCoordinador = false;
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }

                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("delete from Coordinador where Matricula_Coordinador = '@matricula' ", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", matricula));

                    try
                    {
                        command.ExecuteNonQuery();
                        bajaCoordinador = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            bajaCoordinador = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el límite de memoria", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            bajaCoordinador = false;
                            throw new LogicException("Lo sentimos. \nAlgo pasó que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);

                        }

                    }

                    transaction.Commit();

                }
                conexionBaseDatos.CloseConnection();
            }
            return bajaCoordinador;
        }

        /// <summary>
        /// Recupera una Lista de <see cref="Coordinador"/>.
        /// </summary>
        /// <returns>Una lista de <see cref="Coordinador"/>.</returns>
        public List<Coordinador> MostrarCoordinadores()
        {
            List<Coordinador> Coordinadores = new List<Coordinador>();

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Nombre,Apellidos,CorreoElectronico,Matricula_Coordinador,Contraseña,Carrera FROM Coordinador ", connection))
                {

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Coordinador coordinador = new Coordinador();
                        coordinador.nombre = reader["Nombre"].ToString();
                        coordinador.apellidos = reader["Apellidos"].ToString();
                        coordinador.correoElectronico = reader["CorreoElectronico"].ToString();
                        coordinador.numPersonalCoordinador = reader["Matricula_Coordinador"].ToString();
                        coordinador.contraseñaCoordinador = reader["Contraseña"].ToString();
                        coordinador.carreraCoordinar = (Carrera)Enum.Parse(typeof(Carrera), reader["Carrera"].ToString());
                        Coordinadores.Add(coordinador);
                    }

                }
                connection.Close();
            }
            return Coordinadores;
        }

        /// <summary>
        /// Actualiza los datos de un <see cref="Coordinador"/>.
        /// </summary>
        /// <param name="Matricula"><see cref="String"/>.</param>
        /// <param name="Contraseña"><see cref="String"/>.</param>
        /// <param name="Correo"><see cref="String"/>.</param>
        /// <returns>Si la actualizacion fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool EditarCoordinador(String matricula, String contraseña, String correo)
        {
            bool coordinadorActualizado = false;
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }

                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("UPDATE Coordinador set CorreoElectronico = @correo , Contraseña = @contraseña where Matricula_Coordinador = @matricula ", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula",matricula));
                    command.Parameters.Add(new SqlParameter("correo", correo));
                    command.Parameters.Add(new SqlParameter("contraseña",contraseña));
                    try
                    {
                        command.ExecuteNonQuery();
                        coordinadorActualizado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            coordinadorActualizado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el límite de memoria", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            coordinadorActualizado = false;
                            throw new LogicException("Lo sentimos. \nAlgo pasó que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);

                        }

                    }
                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }
            return coordinadorActualizado;
        }

        /// <summary>
        /// Reliza una insercion de datos de un <see cref="Coordinador"/>.
        /// </summary>
        /// <param name="Coordinador"><see cref="Coordinador"/>.</param>
        /// <returns>Si la inserción fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool RegistrarCoordinador(Coordinador coordinador)
        {
            bool coordinadorGuardado = false;


            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Coordinador(Matricula_Coordinador, Nombre, Apellidos, CorreoElectronico, Contraseña, Carrera) values(@matricula, @nombre, @apellido, @correo, @contraseña, @carrera)", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", coordinador.numPersonalCoordinador));
                    command.Parameters.Add(new SqlParameter("nombre", coordinador.nombre));
                    command.Parameters.Add(new SqlParameter("apellido", coordinador.apellidos));
                    command.Parameters.Add(new SqlParameter("correo", coordinador.correoElectronico));
                    command.Parameters.Add(new SqlParameter("contraseña", coordinador.contraseñaCoordinador));
                    command.Parameters.Add(new SqlParameter("carrera", coordinador.carreraCoordinar.ToString()));

                    try
                    {
                        command.ExecuteNonQuery();
                        transaction.Commit();
                        coordinadorGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            coordinadorGuardado = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ExcepcionesLogicas.LlaveDuplicada);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            coordinadorGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ExcepcionesLogicas.ValorFueraDeRango);
                        }
                        else
                        {
                            transaction.Rollback();
                            coordinadorGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ExcepcionesLogicas.FallaGeneral);
                        }
                    }

                    
                }
                conexionBaseDatos.CloseConnection();
            }

            return coordinadorGuardado;
        }

        /// <summary>
        /// Recupera una lista de matriculas de coordinadores.
        /// </summary>
        /// <param name="Id"><see cref="String"/>.</param>
        /// <returns>Si la recuperacion es exitosa.</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool GetIdCoordinador(String id)
        {
            bool idObtenido = false;
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula_Coordinador FROM Coordinador WHERE Matricula_Coordinador = @id", connection))
                {
                    command.Parameters.Add(new SqlParameter("id", id));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Coordinador coordinador = new Coordinador(); ;
                        coordinador.numPersonalCoordinador = reader["Matricula_Coordinador"].ToString();
                        idObtenido = true;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            return idObtenido;
        }
    }
}
