﻿using System;
using BaseDatos;
using System.Data.SqlClient;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo.Emun;
using System.Collections.Generic;

namespace LogicaDeNegocio.AccesoADatos
{
     public class ProyectoDAO : IProyectoDAO
    {
        /// <summary>
        /// Recupera el numero maximo de alumnos admitidos en el proyecto y calcula los vacantes por cada asignación.
        /// <param name="proyecto">de <see cref="String"/>.</param>
        /// </summary>
        /// <returns>Si el calculo fue exitoso.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool CalcularVacanates(String proyecto)
        {
            bool vacantesActualizados = false;

            Proyecto proyecto1 = new Proyecto();

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT  MaxAlumnos, Vacantes, ID_Proyecto FROM Proyecto WHERE ID_Proyecto=@proyecto", connection))
                {
                    command.Parameters.Add(new SqlParameter("proyecto", proyecto));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        
                        proyecto1.maxAlumno = Convert.ToInt32(reader["MaxAlumnos"].ToString());
                        proyecto1.vacantes = Convert.ToInt32(reader["Vacantes"].ToString());
                    }

                    
                }
                connection.Close();
            }

            proyecto1.vacantes = proyecto1.maxAlumno - 1;

            ConexionBaseDatos conexionBaseDatos2 = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos2.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("Update Proyecto SET Vacantes = @vacantes WHERE ID_Proyecto=@proyecto", connection))
                {
                    command.Parameters.Add(new SqlParameter("proyecto", proyecto));
                    command.Parameters.Add(new SqlParameter("vacantes", proyecto1.vacantes));

                    command.ExecuteNonQuery();
                    vacantesActualizados = true;
                }
                connection.Close();
            }

            return vacantesActualizados;
        }

        /// <summary>
        /// Actualiza el estado de <see cref="Proyecto"/>.
        /// </summary>
        /// <param name="EstadoProyecto">de <see cref="Proyecto"/>.</param>
        /// <returns>Si la actualizacion fue exitosa.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public void CambiarEstadoProyecto(Proyecto EstadoProyecto)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Recupera una Lista de <see cref="Proyecto"/>.
        /// </summary>
        /// <returns>Una lista de <see cref="Proyecto"/>.</returns>
        public List<Proyecto> MostrarProyectos()
        {
            List<Proyecto> proyectos = new List<Proyecto>();
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT  MaxAlumnos, Vacantes, ID_Proyecto, Nombre_Proyecto, ID_Institucion, Estado, Encargado FROM Proyecto ", connection))
                {

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Proyecto proyecto = new Proyecto();
                        proyecto.maxAlumno = Convert.ToInt32(reader["MaxAlumnos"].ToString());
                        proyecto.vacantes = Convert.ToInt32(reader["Vacantes"].ToString());
                        proyecto.idProyecto = reader["ID_Proyecto"].ToString();
                        proyecto.nombreProyecto = reader["Nombre_Proyecto"].ToString();
                        proyecto.perteneceA = reader["ID_Institucion"].ToString();
                        proyecto.estadoP = (EstadoProyecto)Enum.Parse(typeof(EstadoProyecto), reader["Estado"].ToString());
                        proyecto.dirigidoPor = reader["Encargado"].ToString();
                        proyectos.Add(proyecto);
                    }
                }
                connection.Close();
            }
            return proyectos;
        }

        /// <summary>
        /// Reliza una insercion de datos de un <see cref="Proyecto"/>.
        /// </summary>
        /// <param name="proyecto"><see cref="Proyecto"/>.</param>
        /// <returns>Si la inserción fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool RegistrarProyeto(Proyecto proyecto)
        {
            bool proyectoGuardado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            proyecto.estadoP = EstadoProyecto.EnEspera;
            proyecto.vacantes = proyecto.maxAlumno;

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Proyecto(ID_Proyecto,Nombre_Proyecto, MaxAlumnos,Vacantes, Encargado, ID_Institucion,Estado) values(@id,@nombre, @maximo,@vacantes, @dirigido, @institucion,@estado)", connection);
                {
                    command.Transaction = transaction;

                    command.Parameters.Add(new SqlParameter("id", proyecto.idProyecto));
                    command.Parameters.Add(new SqlParameter("nombre", proyecto.nombreProyecto));
                    command.Parameters.Add(new SqlParameter("maximo", proyecto.maxAlumno));
                    command.Parameters.Add(new SqlParameter("vacantes", proyecto.vacantes));
                    command.Parameters.Add(new SqlParameter("dirigido", proyecto.dirigidoPor));
                    command.Parameters.Add(new SqlParameter("institucion",proyecto.perteneceA));
                    command.Parameters.Add(new SqlParameter("estado", proyecto.estadoP.ToString()));

                    try
                    {
                        command.ExecuteNonQuery();
                        proyectoGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            proyectoGuardado = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ExcepcionesLogicas.LlaveDuplicada);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            proyectoGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ExcepcionesLogicas.ValorFueraDeRango);
                        }
                        else
                        {
                            transaction.Rollback();
                            proyectoGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ExcepcionesLogicas.FallaGeneral);
                        }
                    }

                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }

            return proyectoGuardado;
        }

        /// <summary>
        /// Recupera una matricula de proyecto.
        /// </summary>
        /// <param name="Id"><see cref="String"/>.</param>
        /// <returns>Si la recuperacion es exitosa.</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool GetIdProyecto(String Id)
        {
            bool idObtenida = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT ID_Proyecto FROM Proyecto WHERE ID_Proyecto = @id", connection))
                {
                    command.Parameters.Add(new SqlParameter("id",Id));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Proyecto proyecto = new Proyecto();
                        proyecto.idProyecto = reader["ID_Proyecto"].ToString();
                        idObtenida = true;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            return idObtenida;
        }

        /// <summary>
        /// Recupera los datos de un proyecto.
        /// </summary>
        /// <param name="matricula"><see cref="String"/>.</param>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public String ObtenerDatos(String Proyecto)
        {
            String idObtenida = "";
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("select Nombre_Proyecto from Proyecto WHERE ID_Proyecto = @proyecto", connection))
                {
                    command.Parameters.Add(new SqlParameter("proyecto", Proyecto));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Proyecto proyecto2 = new Proyecto();
                        proyecto2.idProyecto = reader["Nombre_Proyecto"].ToString();
                        idObtenida = proyecto2.idProyecto.ToString();
                    }
                    reader.Close();
                }
                connection.Close();

            }
            return idObtenida;
        }
    }
}
