﻿using BaseDatos;
using System.Data.SqlClient;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Excepciones;
using System;
namespace LogicaDeNegocio.AccesoADatos
{
    public class TecnicoDAO : ITecnicoDAO
    {
        /// <summary>
        /// Se elimina a un tecnicp.
        /// </summary>
        /// <param name="matricula"><see cref="String"/>.</param>
        /// <returns>Si la eliminacion fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQLException detecta una excepcion</exception>
        public bool DarBajaTecnico(String matricula)
        {
            bool bajaTecnico = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("delete from TecnicoAcad where Matricula_Tecnico = '@matricula' ", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", matricula));

                    try
                    {
                        command.ExecuteNonQuery();
                        bajaTecnico = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            bajaTecnico = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el límite de memoria", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            bajaTecnico = false;
                            throw new LogicException("Lo sentimos. \nAlgo pasó que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);
                        }

                    }

                    transaction.Commit();
                }
                connection.Close();
            }
            return bajaTecnico;
        }

        /// <summary>
        /// Reliza una insercion de datos de un <see cref="TecnicoAcademico"/>.
        /// </summary>
        /// <param name="tecnico"><see cref="TecnicoAcademico"/>.</param>
        /// <returns>Si la inserción fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool RegistrarTecnico(TecnicoAcademico tecnico)
        {
            bool tecnicoGuardado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into TecnicoAcad(Matricula_Tecnico,Nombre, Apellido, CorreoElectronico, Contraseña, Matricula_Coordinador) values(@matricula,@nombre, @apellido, @correo, @contraseña,@coordinador)", connection);
                {
                    command.Transaction = transaction;

                    command.Parameters.Add(new SqlParameter("matricula", tecnico.numPersonalTecnico));
                    command.Parameters.Add(new SqlParameter("nombre", tecnico.nombre));
                    command.Parameters.Add(new SqlParameter("apellido", tecnico.apellidos));
                    command.Parameters.Add(new SqlParameter("correo", tecnico.correoElectronico));
                    command.Parameters.Add(new SqlParameter("contraseña", tecnico.contraseñaTecnico));
                    command.Parameters.Add(new SqlParameter("coordinador", tecnico.auxuliaA));

                    try
                    {
                        command.ExecuteNonQuery();
                        transaction.Commit();
                        tecnicoGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            tecnicoGuardado = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ExcepcionesLogicas.LlaveDuplicada);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            tecnicoGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ExcepcionesLogicas.ValorFueraDeRango);
                        }
                        else if (error == ExcepcionesLogicas.CampoVacio)
                        {
                            transaction.Rollback();
                            tecnicoGuardado = false;
                            throw new LogicException("Se han detectado datos faltantes. \nFavor de ingresar todos los datos.", ExcepcionesLogicas.CampoVacio);
                        }
                        else
                        {
                            transaction.Rollback();
                            tecnicoGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ExcepcionesLogicas.FallaGeneral);
                        }
                    }

                }
                conexionBaseDatos.CloseConnection();
            }

            return tecnicoGuardado;
        }

        /// <summary>
        /// Actualiza los datos de un tecnico.
        /// </summary>
        /// <param name="Matricula"><see cref="String"/>.</param>
        /// <param name="Contraseña"><see cref="String"/>.</param>
        /// <param name="Correo"><see cref="String"/>.</param>
        /// <returns>Si la actualizacion fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool EditarTecnico(String matricula, String correo, String contraseña)
        {
            bool tecnicoActualizado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();

                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("UPDATE TecnicoAcad set CorreoElectronico = @correo , Contraseña = @contraseña where Matricula_Tecnico = @matricula ", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", matricula));
                    command.Parameters.Add(new SqlParameter("correo", correo));
                    command.Parameters.Add(new SqlParameter("contraseña", contraseña));
                    try
                    {
                        command.ExecuteNonQuery();
                        tecnicoActualizado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            tecnicoActualizado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el límite de memoria", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            tecnicoActualizado = false;
                            throw new LogicException("Lo sentimos. \nAlgo pasó que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);

                        }

                    }
                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }
            return tecnicoActualizado;
        }
    }
}
