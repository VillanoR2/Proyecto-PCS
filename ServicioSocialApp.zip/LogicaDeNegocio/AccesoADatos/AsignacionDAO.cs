﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using BaseDatos;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Excepciones;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.Modelo.Emun;

namespace LogicaDeNegocio.AccesoADatos
{
    public class AsignacionDAO : IAsignacionDAO
    {
        /// <summary>
        /// Recupera las horas de los alumnos registrados y la actualiza.
        /// <param name="horas">de <see cref="int"/>.</param>
        /// </summary>
        /// <returns>Una hora actualizada.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public int ActualizarHoras(int horas)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// Actualiza el estado de una asignacion y lo da de baja.
        /// </summary>
        /// <returns>si la actualizacion fue exitosa.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool CambiarEstadoBaja()
        {
            bool EditAlumno = false;
            Alumno alumno = new Alumno();
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                SqlCommand command = connection.CreateCommand();
                SqlTransaction transaction;

                transaction = connection.BeginTransaction("Transacción");

                command.Connection = connection;
                command.Transaction = transaction;

                command = new SqlCommand("update Asignacion set EstadoServicio = 'De Baja' where Matricula = @matricula", connection);
                {
                    command.Parameters.Add(new SqlParameter("matricula", alumno.matricula));
                    try
                    {
                        command.ExecuteNonQuery();
                        EditAlumno = true;
                    }

                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        transaction.Rollback();
                        throw new LogicException("Algo paso que impide la conexión con la base de datos.", error);

                    }

                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }

            return EditAlumno;
        }
        /// <summary>
        /// Recupera el estado de la asignacion de un alumno.
        /// </summary>
        /// <param name="Alumno"><see cref="String"/>.</param>
        /// <returns>El estado de servicio del alumno</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public EstadoServicio ObtenerEstado(String alumno)
        {
            EstadoServicio estadoActual = EstadoServicio.Espera;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            Asignacion solicitud = new Asignacion();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT EstadoServicio FROM Asignacion WHERE Matricula = @matricula", connection))
                {
                    command.Parameters.Add(new SqlParameter("matricula", alumno));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        solicitud.estadoAsignado = (EstadoServicio)Enum.Parse(typeof(EstadoServicio), reader["EstadoServicio"].ToString());

                    }

                    if (solicitud.estadoAsignado == EstadoServicio.Aceptado)
                    {
                        estadoActual = EstadoServicio.Aceptado;
                    }
                    else if (solicitud.estadoAsignado == EstadoServicio.Rechazado)
                    {
                        estadoActual = EstadoServicio.Rechazado;
                    }
                    else
                    {
                        estadoActual = EstadoServicio.Baja;
                    }
                }
                connection.Close();

            }
            return estadoActual;
        }

        /// <summary>
        /// Registra una asignacion de servicio social.
        /// <paramref name="Estado"/><see cref="EstadoServicio"/>
        /// <paramref name="Id"/><see cref="String"/>
        /// <paramref name="Proyecto"/> <see cref="String"/>
        /// </summary>
        /// <returns>Si la insercion fue exitosa.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool RealizarAsignacion(String id, String proyecto, EstadoServicio estado)
        {
            bool asignacionRealizada = false;

            int horas = 0;
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Asignacion(ID_Proyecto, Matricula, Horas, EstadoServicio) values(@id, @matricula, @horas, @estado)", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("id", proyecto));
                    command.Parameters.Add(new SqlParameter("matricula", id));
                    command.Parameters.Add(new SqlParameter("horas", horas));
                    command.Parameters.Add(new SqlParameter("estado", estado.ToString()));

                    try
                    {
                        command.ExecuteNonQuery();
                        asignacionRealizada = true;
                    }
                    catch (SqlException ex)
                    {

                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            asignacionRealizada = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ex);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            asignacionRealizada = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            asignacionRealizada = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);
                        }
                    }

                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }

            return asignacionRealizada;
        }

    }
}
