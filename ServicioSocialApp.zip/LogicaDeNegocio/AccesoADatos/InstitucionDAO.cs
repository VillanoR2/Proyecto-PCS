﻿using System.Data.SqlClient;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Modelo;
using BaseDatos;
using LogicaDeNegocio.Excepciones;
using System;

namespace LogicaDeNegocio.AccesoADatos
{
     public class InstitucionDAO : IInstitucionDAO
    {

        /// <summary>
        /// Reliza una insercion de datos de un <see cref="Institucion"/>.
        /// </summary>
        /// <param name="Institucion"><see cref="Institucion"/>.</param>
        /// <returns>Si la inserción fue exitosa</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool RegistrarInstitucion(Institucion institucion)
        {
            bool institucionGuardado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Institucion(Nombre, Direccion, TipoInstitucion, Telefono) values(@nombre, @direccion, @tipo, @telefono)", connection);
                {
                    command.Transaction = transaction;

                    command.Parameters.Add(new SqlParameter("nombre", institucion.nombreInstitucion));
                    command.Parameters.Add(new SqlParameter("direccion", institucion.direccion));
                    command.Parameters.Add(new SqlParameter("tipo", institucion.tipoInstitucion));
                    command.Parameters.Add(new SqlParameter("telefono", institucion.telefonoInstitucion));
    
                    try
                    {
                        command.ExecuteNonQuery();
                        institucionGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            institucionGuardado = false;
                            throw new LogicException("La institución ingresada ya fue previamente registrada", ExcepcionesLogicas.LlaveDuplicada);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            institucionGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ExcepcionesLogicas.ValorFueraDeRango);
                        }
                        else
                        {
                            transaction.Rollback();
                            institucionGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ExcepcionesLogicas.FallaGeneral);
                        }
                    }

                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }

            return institucionGuardado;
        }

        /// <summary>
        /// Recupera una lista de nombres de instituciones.
        /// </summary>
        /// <param name="Nombre"><see cref="String"/>.</param>
        /// <returns>Si la recuperacion es exitosa.</returns>
        /// <exception cref="LogicException">Lanza una excepcion si SQL detecta una excepcion</exception>
        public bool GetNombreInsitucion(String nombre)
        {
            bool nombreObtenido = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT Nombre FROM Institucion WHERE Nombre = @nombre", connection))
                {
                    command.Parameters.Add(new SqlParameter("nombre", nombre));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Institucion institucion = new Institucion();
                        institucion.nombreInstitucion = reader["Nombre"].ToString();
                        nombreObtenido = true;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            return nombreObtenido;
        }

    }
}
