﻿using System;
using System.Data.SqlClient;
using BaseDatos;
using LogicaDeNegocio.Modelo;
using LogicaDeNegocio.AccesoADatos.Interfaces;
using LogicaDeNegocio.Excepciones;
using System.Collections.Generic;
using LogicaDeNegocio.Modelo.Emun;
using System.Data;

namespace LogicaDeNegocio.AccesoADatos
{
    /// <summary>
    /// Clase de abstraccion para acceso a objetos <see cref="Alumno"/> en la base de datos.
    /// Contiene metodos para cargar, insertar y actualizar objetos <see cref="Alumno"/>.
    /// </summary>
    public class AlumnoDAO : IAlumnoDAO
    {
        /// <summary>
        /// Recupera una lista de <see cref="Alumno"/> dada su <see cref="Alumno.CarreraAlumno"/>.
        /// Muestra Matricula, Nombre, Apellidos, Carrera y CorreoElectronico.
        /// </summary>
        /// <param name="Carrera">Carrera de un alumno de <see cref="Carrera"/>.</param>
        /// <returns>Una lista de<see cref="alumnos"/> de <see cref="Alumno"/></returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public List<Alumno> MostrarAlumnosAvance(Carrera carrera)
        {
            List<Alumno> alumnos = new List<Alumno>();
        
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }catch(SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var Error = excepcion.SqlErrorMessage();
                    if (Error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }else if(Error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (Error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }else if(Error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula,Nombres,Apellidos,Carrera,CorreoElectronico FROM Alumno WHERE Carrera = @carrera ",connection))
                {
                    command.Parameters.Add(new SqlParameter("carrera", carrera.ToString()));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Alumno alumno = new Alumno();
                        alumno.matricula = reader["Matricula"].ToString();
                        alumno.nombre = reader["Nombres"].ToString();
                        alumno.apellidos = reader["Apellidos"].ToString();
                        alumno.carreraAlumno = (Carrera)Enum.Parse(typeof(Carrera), reader["Carrera"].ToString());
                        alumno.correoElectronico = reader["CorreoElectronico"].ToString();
                        alumnos.Add(alumno);
                    }
                    
                }
                    connection.Close();
            }
            return alumnos;
        }

        /// <summary>
        /// Recupera una lista de <see cref="Alumno"/>
        /// Muestra Matricula, Nombre, Apellidos, Carrera y CorreoElectronico.
        /// </summary>
        /// <returns>Una lista de<see cref="Alumnos"/> de <see cref="Alumno"/></returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public List<Alumno> MostrarAlumnosSolicitud()
        {
            List<Alumno> alumnos = new List<Alumno>();

            var Estado = EstadoSolicitud.EnEspera;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var Error = excepcion.SqlErrorMessage();
                    if (Error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (Error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (Error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (Error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                    using (SqlCommand command = new SqlCommand("SELECT Matricula, Nombres, Apellidos, EstadoSolicitud FROM Alumno,Solicitud WHERE Alumno.Matricula = Solicitud.Matricula_Alumno AND EstadoSolicitud = @estado;", connection))
                {
                    command.Parameters.Add(new SqlParameter("estado", Estado.ToString()));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Alumno alumno = new Alumno();
                        alumno.matricula = reader["Matricula"].ToString();
                        alumno.nombre = reader["Nombres"].ToString();
                        alumno.apellidos = reader["Apellidos"].ToString();
                        alumno.estado = (EstadoSolicitud)Enum.Parse(typeof(EstadoSolicitud), reader["EstadoSolicitud"].ToString());
                        
                        alumnos.Add(alumno);
                    }

                }
                connection.Close();
            }
            return alumnos;
        }

        /// <summary>
        /// Ingresa un registro de <see cref="Alumno"/>
        /// Solicita Matricula, Nombre, Apellidos, Carrera y CorreoElectronico.
        /// <param name="alumno">de <see cref="Alumno"/>.</param>
        /// </summary>
        /// <returns>Si la inserción de datos es existosa</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool RegistrarAlumno(Alumno alumno)
        {
            bool alumnoGuardado = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("Insert into Alumno(Matricula, Nombres, Apellidos, CorreoElectronico, Contraseña, Carrera) values(@matricula, @nombre, @apellido, @correo, @contraseña, @carrera)", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", alumno.matricula));
                    command.Parameters.Add(new SqlParameter("nombre", alumno.nombre));
                    command.Parameters.Add(new SqlParameter("apellido", alumno.apellidos));
                    command.Parameters.Add(new SqlParameter("correo", alumno.correoElectronico));
                    command.Parameters.Add(new SqlParameter("contraseña", alumno.contraseñaAlumno));
                    command.Parameters.Add(new SqlParameter("carrera", alumno.carreraAlumno.ToString()));
          
                    
                    try
                    {
                        command.ExecuteNonQuery();
                        alumnoGuardado = true;
                    }
                    catch (SqlException ex)
                    {
                        
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.LlaveDuplicada)
                        {
                            transaction.Rollback();
                            alumnoGuardado = false;
                            throw new LogicException("La matricula ingresada ya fue previamente asignada", ex);
                        }
                        else if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            alumnoGuardado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el limite de memoria.", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            alumnoGuardado = false;
                            throw new LogicException("Lo sentimos. \nAlgo paso que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);
                        }
                    }

                        transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }

            return alumnoGuardado;
        }

        /// <summary>
        /// Actualiza los datos de <see cref="Alumno"/>
        /// Solicita Matricula, Contraseña y CorreoElectronico.
        /// <param name="Matricula">de <see cref="String"/>.</param>
        /// <param name="Contraseña">de <see cref="String"/>.</param>
        /// <param name="Correo">de <see cref="String"/>.</param>
        /// </summary>
        /// <returns>Si la actualización de datos es existosa</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool EditarAlumno(String matricula, String contraseña, String correo)
        {
            bool alumnoActualizado = false;
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }

                SqlCommand command = connection.CreateCommand();

                SqlTransaction transaction = connection.BeginTransaction("Transaccion");

                command.Connection = connection;

                command = new SqlCommand("UPDATE Alumno set CorreoElectronico = @correo , Contraseña = @contraseña where Matricula = @matricula ", connection);
                {
                    command.Transaction = transaction;
                    command.Parameters.Add(new SqlParameter("matricula", matricula));
                    command.Parameters.Add(new SqlParameter("correo", correo));
                    command.Parameters.Add(new SqlParameter("contraseña", contraseña));
                    try
                    {
                        command.ExecuteNonQuery();
                        alumnoActualizado = true;
                    }
                    catch (SqlException ex)
                    {
                        var excepcion = new LogicException(ex);
                        var error = excepcion.SqlErrorMessage();
                        if (error == ExcepcionesLogicas.ValorFueraDeRango)
                        {
                            transaction.Rollback();
                            alumnoActualizado = false;
                            throw new LogicException("Lo sentimos, se estan tratando de ingresar valores que exceden el límite de memoria", ex);
                        }
                        else
                        {
                            transaction.Rollback();
                            alumnoActualizado = false;
                            throw new LogicException("Lo sentimos. \nAlgo pasó que impide la conexión con la base de datos, \nesta siendo redireccionado a la pantalla anterior.", ex);

                        }

                    }
                    transaction.Commit();
                }
                conexionBaseDatos.CloseConnection();
            }
            return alumnoActualizado;
        }

        /// <summary>
        /// Recupera la <see cref="Carrera"/> de los alumnos registrados.
        /// <param name="Carrera">de <see cref="Carrera"/>.</param>
        /// </summary>
        /// <returns>Una <see cref="Carrera"/>.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public Carrera ObtenerCarrera(Carrera carrera)
        {
            Carrera CarreraActual = Carrera.IngenieriaDeSoftware;
           
            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            Alumno alumno = new Alumno();
           
            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Carrera FROM Alumno WHERE Carrera = @carrera", connection))
                {
                    command.Parameters.Add(new SqlParameter("@carrera",carrera.ToString()));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        alumno.carreraAlumno = (Carrera)Enum.Parse(typeof(Carrera), reader["Carrera"].ToString());

                    }

                    if (alumno.carreraAlumno == Carrera.IngenieriaDeSoftware)
                    {
                        CarreraActual = Carrera.IngenieriaDeSoftware;
                    }
                    else if (alumno.carreraAlumno == Carrera.RedesyServiciosDeComputo)
                    {
                        CarreraActual = Carrera.RedesyServiciosDeComputo;
                    }
                    else
                    {
                        CarreraActual = Carrera.TecnologiasComputacionales;
                    }

                }
                connection.Close();

            }
            return CarreraActual;
        }

        /// <summary>
        /// Recupera la matricula de <see cref="Alumno"/> .
        /// <param name="alumno">de <see cref="string"/>.</param>
        /// </summary>
        /// <returns>Si la recuperacion fue exitosa.</returns>
        /// <exception cref="LogicException">lanza esta excepcion si el cliente de SQL detecto una excepción.</exception>
        public bool GetMatricula(string alumno)
        {
            bool idObtenida = false;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula FROM Alumno WHERE Matricula = @id", connection))
                {
                    command.Parameters.Add(new SqlParameter("id", alumno));
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Proyecto proyecto = new Proyecto();
                        proyecto.idProyecto = reader["Matricula"].ToString();
                        idObtenida = true;
                    }
                    reader.Close();
                }
                connection.Close();
            }
            return idObtenida;
        }
    }
}
