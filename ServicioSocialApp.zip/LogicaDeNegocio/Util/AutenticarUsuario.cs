﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaseDatos;
using LogicaDeNegocio.Excepciones;
using System.Data.SqlClient;
namespace LogicaDeNegocio.Util
{
    public enum ResultadoAutenticacion
    {
        UsuarioInexistente,
        Alumno,
        Coordinador,
        Director,
        Tecnico
    }
    public class AutenticarUsuario
    {
        /// <summary>
        /// Valida los datos de ingreso propocionados por el usuario.
        /// </summary>
        /// <param name="Usuario">Matricula del usuario.</param>
        /// <param name="Contraseña">Contraseña del usuario.</param>
        /// <returns>Si se cumple la validacion, se regresa el tipo de usuario.</returns>
        public ResultadoAutenticacion resultadoAutenticacion(String usuario, String contraseña)
        {
            ResultadoAutenticacion resultadoAutenticacion = ResultadoAutenticacion.UsuarioInexistente;

            ConexionBaseDatos conexionBaseDatos = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT NumPersonal FROM Director WHERE NumPersonal = @usuario and Contraseña = @contraseña", connection))
                {
                    command.Parameters.Add(new SqlParameter("@usuario", usuario));
                    command.Parameters.Add(new SqlParameter("@contraseña", contraseña));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        usuario = reader["NumPersonal"].ToString();
                        resultadoAutenticacion = ResultadoAutenticacion.Director;
                    }

                    reader.Close();
                    connection.Close();
                }
            }

            ConexionBaseDatos conexionBaseDatos2 = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos2.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula FROM Alumno WHERE Matricula = @usuario and Contraseña = @contraseña", connection))
                {
                    command.Parameters.Add(new SqlParameter("@usuario", usuario));
                    command.Parameters.Add(new SqlParameter("@contraseña", contraseña));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        usuario = reader["Matricula"].ToString();
                        resultadoAutenticacion = ResultadoAutenticacion.Alumno;
                    }

                    reader.Close();
                    connection.Close();
                }
            }

            ConexionBaseDatos conexionBaseDatos3 = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos3.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula_Coordinador FROM Coordinador WHERE Matricula_Coordinador = @usuario and Contraseña = @contraseña", connection))
                {
                    command.Parameters.Add(new SqlParameter("@usuario", usuario));
                    command.Parameters.Add(new SqlParameter("@contraseña", contraseña));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        usuario = reader["Matricula_Coordinador"].ToString();
                        resultadoAutenticacion = ResultadoAutenticacion.Coordinador;
                    }

                    reader.Close();
                    connection.Close();
                }
            }

            ConexionBaseDatos conexionBaseDatos4 = new ConexionBaseDatos();

            using (SqlConnection connection = conexionBaseDatos4.GetConnection())
            {
                try
                {
                    connection.Open();
                }
                catch (SqlException e)
                {
                    var excepcion = new LogicException(e);
                    var error = excepcion.SqlErrorMessage();
                    if (error == ExcepcionesLogicas.ConexionAServidorFallida)
                    {
                        throw new LogicException("Conexión con el servidor fallida", ExcepcionesLogicas.ConexionAServidorFallida);
                    }
                    else if (error == ExcepcionesLogicas.LoginFallido)
                    {
                        throw new LogicException("La conexión con el servidor fallo debido a un error en el usuario.", ExcepcionesLogicas.LoginFallido);
                    }
                    else if (error == ExcepcionesLogicas.ServidorNoEncontrado)
                    {
                        throw new LogicException("Error, servidor no encontrado.", ExcepcionesLogicas.ServidorNoEncontrado);
                    }
                    else if (error == ExcepcionesLogicas.TiempodeEsperaExpirado)
                    {
                        throw new LogicException("Se agoto el tiempo de espera", ExcepcionesLogicas.TiempodeEsperaExpirado);
                    }
                    else
                    {
                        throw new LogicException("Imposible conectarse a la base de datos.", ExcepcionesLogicas.FallaGeneral);
                    }
                }
                using (SqlCommand command = new SqlCommand("SELECT Matricula_Tecnico FROM TecnicoAcad WHERE Matricula_Tecnico = @usuario and Contraseña = @contraseña", connection))
                {
                    command.Parameters.Add(new SqlParameter("@usuario", usuario));
                    command.Parameters.Add(new SqlParameter("@contraseña", contraseña));

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        usuario = reader["Matricula_Tecnico"].ToString();
                        resultadoAutenticacion = ResultadoAutenticacion.Tecnico;
                    }

                    reader.Close();
                    connection.Close();
                }
            }


            return resultadoAutenticacion;
        }
    }

}

