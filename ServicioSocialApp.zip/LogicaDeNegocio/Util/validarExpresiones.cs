﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LogicaDeNegocio.Util
{
    public class validarExpresiones
    {
        public bool ValidarRegex(String cadenaValida, String cadenaIngresada)
        {
            bool resultado;
            Regex regex = new Regex(cadenaValida);
            if (regex.IsMatch(cadenaIngresada))
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;     
        }
        public bool EmailValido(String email)
        {
            bool resultado;
            String formatoEmail = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
             @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
               @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

            if(ValidarRegex(formatoEmail,email) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;
            
        }

        public bool NombreValido(String nombre)
        {
            bool resultado;
            String formatoNombre = @"^([A-Za-z])";
            if (ValidarRegex(formatoNombre, nombre) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;

        }

        public bool MatriculaValida(String matricula)
        {
            bool resultado;
            String formatoMatricula = @"^([A-Z\s]{1})\d{8}$";

            if (ValidarRegex(formatoMatricula, matricula) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;


        }

        public bool ContrasenaValida(String contrasena)
        {
            bool resultado;
            String formatoContrasena = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])([A-Za-z\d$@$!%*?&]|[^ ]){8,15}$";
            if (ValidarRegex(formatoContrasena, contrasena) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;

        }

        public bool TelefonoValido(String numero)
        {
            bool resultado;
            String formatoTelefono = @"^([0-9]{10})$";

            if (ValidarRegex(formatoTelefono, numero) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;

        }

        public bool DomicilioValido(String direccion)
        {
            bool resultado;
            String formatoDomicilio = @"^((\w+(\s?)){3-35})|\s((\w+(\s?)){3-35})?";

            if (ValidarRegex(formatoDomicilio, direccion) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;
        }

        public bool IdProyectoValido(String proyecto)
        {
            bool resultado;
            String formatoId = @"^([A-Z\s]{1})\d{4}$";
            if (ValidarRegex(formatoId, proyecto) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;

        }
        public bool MaxAlumnosValido(String maximo)
        {
            bool resultado;
            String formatoMaximoAlumnos = @"^([1-9]{1})$";
            if (ValidarRegex(formatoMaximoAlumnos, maximo) == true)
            {
                resultado = true;
            }
            else
            {
                resultado = false;
            }
            return resultado;

        }

    }
}
