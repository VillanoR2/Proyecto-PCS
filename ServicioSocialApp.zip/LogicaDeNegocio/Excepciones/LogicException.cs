﻿using System;
using System.Data.SqlClient;

namespace LogicaDeNegocio.Excepciones
{
    public class LogicException : Exception
    {
        private readonly ExcepcionesLogicas _excepcionLogica; 

        public LogicException()
        {
        }

        public LogicException(string message) : base(message)
        {
        }

        public LogicException(string message, Exception innerException) : base(message, innerException)
        {
        }

        public LogicException(string message, ExcepcionesLogicas excepcionLogica) : base(message)
        {
            _excepcionLogica = excepcionLogica;
        }

        public LogicException(SqlException sql) : base(sql.Message, sql)
        {
            if (sql.Errors.Count > 0)
            {
                var error = sql.Errors[0];
                var number = error.Number;
                if (number == 2627)
                {
                    _excepcionLogica = ExcepcionesLogicas.LlaveDuplicada;
                }
                else if (number == 8152)
                {
                    _excepcionLogica = ExcepcionesLogicas.ValorFueraDeRango;
                }
                else if (number == 8178)
                {
                    _excepcionLogica = ExcepcionesLogicas.CampoVacio;
                }
                else if (number == -1)
                {
                    _excepcionLogica = ExcepcionesLogicas.ConexionAServidorFallida;
                }
                else if (number == 18456)
                {
                    _excepcionLogica = ExcepcionesLogicas.LoginFallido;
                }
                else if (number == -2)
                {
                    _excepcionLogica = ExcepcionesLogicas.TiempodeEsperaExpirado;
                }
                else if (number == 53)
                {
                    _excepcionLogica = ExcepcionesLogicas.ServidorNoEncontrado;
                }
                else
                {
                    _excepcionLogica = ExcepcionesLogicas.FallaGeneral;
                }
            }
        }

        public LogicException(string message, ExcepcionesLogicas excepcionLogica, Exception innerException) : base(message, innerException)
        {
            _excepcionLogica = excepcionLogica;
        }

        public ExcepcionesLogicas SqlErrorMessage()
        {
            return _excepcionLogica;
        }
    }
}
