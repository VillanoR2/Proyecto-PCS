﻿namespace LogicaDeNegocio.Excepciones
{
    public enum ExcepcionesLogicas
    {
        LlaveDuplicada = 2627,
        ValorFueraDeRango= 8152,
        CampoVacio = 8178,
        FallaGeneral = 0,
        ConexionAServidorFallida = -1,
        TiempodeEsperaExpirado = -2,
        ServidorNoEncontrado = 53,
        LoginFallido = 18456,
        InvalidSaveData
    }

}
